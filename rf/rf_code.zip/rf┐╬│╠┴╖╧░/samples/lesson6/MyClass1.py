from robot.api import logger

class MyClass1():
    def  printsomething(self):
        logger.console('oh my')