def returnlist():
    return [1,2]

def _returnlist2():
    return [1,2]
