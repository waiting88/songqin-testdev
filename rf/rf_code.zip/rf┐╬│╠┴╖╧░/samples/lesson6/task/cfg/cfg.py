
MgrLoginUrl =          'http://localhost/mgr/login/login.html'
StudentLoginUrl =      'http://localhost/stduent/login/login.html'
database =             ['127.0.0.1',  '3306']
adminuser =            {'name':'auto', 'pw':'sdfsdfsdf'}