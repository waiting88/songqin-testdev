from robot.api import logger
class WebOpAdmin():
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'

    def __init__(self):
        logger.console('***** OpAdmin init')

    def op1(self):

        print 'ok'
