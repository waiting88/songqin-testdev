# coding:utf8
from selenium import webdriver

executable_path = r"d:\tools\webdrivers\chromedriver.exe"


driver = webdriver.Chrome(executable_path)
driver.implicitly_wait(4)

# ----------------------------
driver.get('http://ci.ytesting.com/mgr/login/login.html')
driver.find_element_by_id('username').send_keys('auto')
driver.find_element_by_id('password').send_keys('sdfsdfsdf')
driver.find_element_by_tag_name('button').click()

eles = driver.find_elements_by_css_selector('tr>td:nth-child(2)')

lessons = []
for ele in eles:
    lessons.append(ele.text)

expected = [u'初中数学',u'初中语文']

if  lessons == expected:
    print 'pass'
else:
    print 'fail!!'
# ----------------------------

driver.quit()