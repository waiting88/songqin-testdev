# coding:utf8
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import cfg
import time
from robot.api import logger

class WebOpAdmin():

    ROBOT_LIBRARY_SCOPE = 'GLOBAL'

    def SetupWebTest(self,driverType='chrome'):
        if driverType == 'chrome':
            self.cur_wd = webdriver.Chrome()
        elif driverType == 'firefox':
            self.cur_wd = webdriver.Firefox()
        else:
            raise Exception('unknow type of webdriver %s'% driverType)

        self.cur_wd.implicitly_wait(2)

    def TearDownWebTest(self):
        self.cur_wd.quit()


    def LoginWebSite(self,username,password):
        self.cur_wd.get(cfg.MgrLoginUrl)
        self.cur_wd.find_element_by_id('username').send_keys(username)
        self.cur_wd.find_element_by_id('password').send_keys(password)
        self.cur_wd.find_element_by_tag_name('button').click()

    def DeleteAll(self,objName):
        self.EnterTab(objName)

        while True:
            delButtons = self.cur_wd.find_elements_by_css_selector("*[ng-click^='delOne']")
            if delButtons == []:
                break

            delButtons[0].click()
            self.cur_wd.find_element_by_css_selector('.modal-footer .btn-primary').click()
            time.sleep(1)


    def EnterTab(self,name):
        tabLinkCss =  u'ul.nav a[ui-sref={}]'.format(name)
        self.cur_wd.find_element_by_css_selector(tabLinkCss).click()
        time.sleep(1)



    def AddTeacher(self,realname,username,desc,idx,lesson):
        self.EnterTab('teacher')

        self.cur_wd.find_element_by_css_selector('button[ng-click^=showAddOne]').click()

        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.realname']")
        ele.clear()
        ele.send_keys(realname)


        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.username']")
        ele.clear()
        ele.send_keys(username)


        ele = self.cur_wd.find_element_by_css_selector("textarea[ng-model='addEditData.desc']")
        ele.clear()
        ele.send_keys(desc)


        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.display_idx']")
        ele.clear()
        ele.send_keys(idx)

        ele = Select(self.cur_wd.find_element_by_css_selector('select[ng-model*=courseSelected]'))
        ele.select_by_visible_text(lesson)

        self.cur_wd.find_element_by_css_selector('button[ng-click*=addTeachCourse]').click()

        self.cur_wd.find_element_by_css_selector('button[ng-click^=addOne]').click()

        time.sleep(1)



    def AddCourse(self,name,desc,idx):
        self.EnterTab('course')

        self.cur_wd.find_element_by_css_selector('button[ng-click^=showAddOne]').click()

        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addData.name']")
        ele.clear()
        ele.send_keys(name)

        ele = self.cur_wd.find_element_by_tag_name("textarea")
        ele.clear()
        ele.send_keys(desc)

        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addData.display_idx']")
        ele.clear()
        ele.send_keys(idx)

        self.cur_wd.find_element_by_css_selector('button[ng-click^=addOne]').click()

        time.sleep(1)




    def AddTraining(self,name,desc,idx,lesson):
        self.EnterTab('training')

        self.cur_wd.find_element_by_css_selector('button[ng-click^=showAddOne]').click()

        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.name']")
        ele.clear()
        ele.send_keys(name)



        ele = self.cur_wd.find_element_by_css_selector("textarea[ng-model='addEditData.desc']")
        ele.clear()
        ele.send_keys(desc)


        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.display_idx']")
        ele.clear()
        ele.send_keys(idx)

        ele = Select(self.cur_wd.find_element_by_css_selector('select[ng-model*=courseSelected]'))
        ele.select_by_visible_text(lesson)

        self.cur_wd.find_element_by_css_selector('button[ng-click*=addTeachCourse]').click()

        self.cur_wd.find_element_by_css_selector('button[ng-click^=addOne]').click()

        time.sleep(1)



    def AddTraininggrade(self,name,desc,idx,training):
        self.EnterTab('traininggrade')

        self.cur_wd.find_element_by_css_selector('button[ng-click^=showAddOne]').click()

        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.name']")
        ele.clear()
        ele.send_keys(name)



        ele = self.cur_wd.find_element_by_css_selector("textarea[ng-model='addEditData.desc']")
        ele.clear()
        ele.send_keys(desc)


        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.display_idx']")
        ele.clear()
        ele.send_keys(idx)

        ele = Select(self.cur_wd.find_element_by_css_selector("select[ng-model*='addEditData.training_id']"))
        ele.select_by_visible_text(training)


        self.cur_wd.find_element_by_css_selector('button[ng-click^=addOne]').click()

        time.sleep(1)





    def AddStudent(self,realname,username,desc,training,traininggrade):
        self.EnterTab('student')

        self.cur_wd.find_element_by_css_selector('button[ng-click^=showAddOne]').click()

        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.realname']")
        ele.clear()
        ele.send_keys(realname)


        ele = self.cur_wd.find_element_by_css_selector("input[ng-model='addEditData.username']")
        ele.clear()
        ele.send_keys(username)


        ele = self.cur_wd.find_element_by_css_selector("textarea[ng-model='addEditData.desc']")
        ele.clear()
        ele.send_keys(desc)


        ele = Select(self.cur_wd.find_element_by_css_selector('select[ng-model*="addEditData.training_id"]'))
        ele.select_by_visible_text(training)


        ele = Select(self.cur_wd.find_element_by_css_selector('select[ng-model*="addEditData.traininggrade_id"]'))
        ele.select_by_visible_text(traininggrade)


        self.cur_wd.find_element_by_css_selector('button[ng-click^=addOne]').click()

        time.sleep(1)




    def GetTeacherList(self):
        self.EnterTab('teacher')

        eles = self.cur_wd.find_elements_by_css_selector('tr>td:nth-child(2)')

        return  [ele.text for ele in eles]

    def GetCourseList(self):
        self.EnterTab('course')

        eles = self.cur_wd.find_elements_by_css_selector('tr>td:nth-child(2)')
        return [ele.text for ele in eles]


    def GetStudentList(self):
        self.EnterTab('student')

        eles = self.cur_wd.find_elements_by_css_selector('tr>td:nth-child(2)')


        return [ele.text for ele in eles]


def test():
    wo = WebOpAdmin()
    # 打开浏览器，创建webdrier
    wo.SetupWebTest()
    wo.LoginWebSite('auto','sdfsdfsdf')


    wo.DeleteAll('student')
    wo.DeleteAll('traininggrade')
    wo.DeleteAll('training')
    wo.DeleteAll('teacher')
    wo.DeleteAll('course')
    wo.AddCourse(u'初中化学',u'...','3')
    wo.AddTraining(u'高中班','...','1',u'初中化学')
    wo.AddTraininggrade(u'高中班1期','...','1',u'高中班')
    wo.AddStudent(u'关羽',u'guanyu','...',u'高中班',u'高中班1期')
    students = wo.GetStudentList()
    for one in students:
        print one

if __name__== '__main__':
    test()