import winsound

def  beep():
    winsound.Beep(1500, 3000)  # freqency and duration