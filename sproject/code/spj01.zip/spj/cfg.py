MgrLoginUrl  =      'http://localhost/mgr/login/login.html'
StudentLoginUrl=    'http://localhost/student/login/login.html'

database=           ['127.0.0.1'  , '3306']
adminuser=          {'name':'auto'  ,  'pw':'sdfsdfsdf'}


g_vcode = '00000000056937869190'