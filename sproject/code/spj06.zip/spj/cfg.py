g_vcode = '00000000056937869190'

g_subject_math_id    = 1
g_subject_science_id = 5

g_grade_7_id      = 1

g_teacher_login_url = 'http://ci.ytesting.com/teacher/login/login.html'



