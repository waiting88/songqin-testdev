g_vcode = '00000000056937869147'

g_subject_math_id    = 1
g_subject_science_id = 5

g_grade_7_id      = 1

g_test_host =  'ci.ytesting.com' #  'ci.ytesting.com' ,'118.31.38.237'

g_teacher_login_url = f'http://{g_test_host}/teacher/login/login.html'
g_student_login_url = f'http://{g_test_host}/student/login/login.html'

g_schoolclass_api_path = f'http://{g_test_host}/api/3school/school_classes'
g_teacher_api_path = f'http://{g_test_host}/api/3school/teachers'
g_student_api_path = f'http://{g_test_host}/api/3school/students'




