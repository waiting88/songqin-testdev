g_host     = 'localhost'

g_login_url =  f"http://{g_host}/api/mgr/loginReq"
g_course_url =  f"http://{g_host}/api/mgr/sq_mgr/"