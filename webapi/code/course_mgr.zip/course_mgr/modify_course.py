# coding:utf8
import requests,json

payload  = {
    'action':'modify_course',
    'id': '453',
    'newdata':u'{"name":"初中化学2","desc":"初中化学课程2","display_idx":"4"}'
}

response = requests.put("http://localhost/api/mgr/sq_mgr/",data=payload)


r = response.json()
print json.dumps(r,indent=2).decode("unicode-escape")




