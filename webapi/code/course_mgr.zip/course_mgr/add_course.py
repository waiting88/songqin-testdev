# coding=utf8
import requests,json


payload  = {
    'action':'add_course',
    'data':u'{"name":"初中化学44","desc":"初中化学课程44","display_idx":"4"}'
}

response = requests.post("http://localhost/api/mgr/sq_mgr/",data=payload)

r = response.json()
print json.dumps(r,indent=2).decode("unicode-escape")



