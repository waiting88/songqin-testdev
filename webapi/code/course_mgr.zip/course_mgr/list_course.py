import requests,json

params = {'action':'list_course', 'pagenum':'1', 'pagesize':20 }
response = requests.get("http://localhost/api/mgr/sq_mgr/",params=params)

r = response.json()
print json.dumps(r,indent=2).decode("unicode-escape")

