import os
os.getcwd()
f = open('file1.txt', 'r').read()
print f
file2 = []
file2 = f.split('\n')
print file2
for i in range(0,len(file2),1):
    a=file2[i].split(';')
    print '%s:''%-6s;''%s:''%-8s;''tax:%-8d;''income:%-8d' % (a[0].split(':')[0].strip(), a[0].split(':')[1].strip(), a[1].split(':')[0].strip(), a[1].split(':')[1].strip(),float(a[1].split(':')[1].strip())*float(0.1),float(a[1].split(':')[1].strip())*float(0.9))

