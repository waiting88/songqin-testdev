def incomInfo(path):
	file1 = open(path)
	messageAll=''
	showMessage = file1.readlines()
	for k in showMessage :
		separate = k.split(';')
		separateName = separate[0]
		separateSlary = separate[1]
		Namelist = separateName.split(':')
		Namelist1 = Namelist[1].strip()
		Slarylist = separateSlary.split(':')
		Slarylist1 = Slarylist[1].strip()
		salary = Slarylist[1]
		tax = float(salary)*0.1
		income = float(salary)*0.9
		message = 'name:%-5s; salary:%-6s; tax:%-7s; income:%-7s\n'%(Namelist1,Slarylist1,tax,income)
		messageAll = messageAll  + message
	with open('C:/Users/ma.yc/Desktop/file2.txt','w') as f :
		file2 = f.write(messageAll)
	print messageAll

incomInfo('C:/Users/ma.yc/Desktop/file1.txt')


