import os

def parseFile(file):
    newlines = []
    for line in open('file1.txt','r').readlines():
        line=line.strip().replace(" ","")
        name = line.split(";")[0].split(":")[1]
        salary = int(line.split(";")[1].split(":")[1])
        newlines.append([name, salary])
    print newlines
    return newlines

def writeData(list, file):
      f = open('file2.txt', 'w+')
      formate = "Name:%s;salary:%d;tax:%d;income:%d\n"
      for i in list:
          name = i[0]
          sl = i[1]
          f.write(formate % (name, sl, sl / 10, sl / 10 * 9))
      f.close()

fileData=parseFile('file1.txt')
writeData(fileData,'file2.txt')