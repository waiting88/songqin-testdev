# -*- coding: UTF-8 -*-
__author__ = 'fjj'
f = open('C:/file1.txt', 'r')
for line in f.readlines():
    line_1 = line.strip()
    a = [int(s) for s in line_1.split(' ') if s.isdigit()]
    line_1 += ('; tax:%d;  income:%d' % (a[0] * 0.1, a[0] * 0.9))
    line_2 = ''.join(line_1.split())
    list_1 = line_2.split(';')
    list_3 = []
    for i in range(len(list_1)):
        list_2 = list_1[i].split(':')
        b = '%-7s:%6s' % (list_2[0], list_2[1])
        list_3.append(b)
    c = '; '.join(list_3)
    print c
    f2 = open('C:/file2.txt', 'a')
    f2.write(c)
    f2.write('\n')
f2.close()
