#coding=utf-8
# -*- coding:gb2312 -*-
'''现有文件1（见附件 file1.txt）， 记录了公司员工的薪资，其内容格式如下

每个员工一行，记录了员工的姓名和薪资， 每行记录 原始文件中并不对齐，中间有或多或少的空格
现要求实现一个python程序，计算出所有员工的税后工资（薪资的90%）和扣税明细，以如下格式存入新的文件2中，如下所示
name: Jack   ;    salary:  12000 ;  tax: 1200 ; income:  10800
name: Mike   ;    salary:  12300 ;  tax: 1230 ; income:  11070
name: Luk    ;    salary:  10030 ;  tax: 1003 ; income:   9027
name: Tim    ;    salary:   9000 ;  tax:  900 ; income:   8100
name: John   ;    salary:  12000 ;  tax: 1200 ; income:  10800
name: Lisa   ;    salary:  11000 ;  tax: 1100 ; income:   9900
要求对齐，上面看着如果不齐，应该是字体原因
tax 表示扣税金额和 income表示实际收入。注意扣税金额和 实际收入要取整数  '''
import os
print os.getcwd()
file_object=open('C:\\Users\\admin\\Desktop\\file1.txt','r')
print file_object.tell()
info=file_object.read()#原始员工信息
print '原始数据工资：\n'+info#显示原始员工信息
employeelist=info.split('\n')#切分信息存入list
print employeelist
for one in employeelist:
    person=one.split(';')
    person[0]=person[0].strip()#去除名字前后空格
    person[1]=person[1].strip()#去除工资前后空格
    #取出工资存入list
    salary=person[1].split(':')
    # print person[0]
    # print len(person[0])
    if len(person[0])<15:#判断名字长度，不足15在末尾补空
        a='{:<15}'.format(person[0])
        person[0] =a
    num=salary[1].strip()#去除工资数字前后空格
    #判断tax长度不足7后面补空
    tax=str(int(float(num )* 0.1))
    if len(tax)<7:
        tax='{:>7}'.format(tax)
        person.append('tax:'+tax)#加入计算的tax工资
    # 判断income长度不足7后面补空
    income = str(int(float(num) * 0.9))
    if len(income)<7:
        income='{:>7}'.format(income)
    person.append('income:' + income)#加入计算的income工资
    #判断salary的长度不足7后面补空
    if len(num)<7:
        num='{:>7}'.format(num)

    person[1]='salary:'+num
    print person
   # 写入
    file_object2=open('C:\\Users\\admin\\Desktop\\file2.txt','a+')
   # while i<len(person):
    for writ in person:#循环写入文件
         file_object2.write(writ+';  ')
    file_object2.write( '\n')
    file_object2.flush()
    file_object2.close()#关闭了写流
file_object.close()#关闭了读流

