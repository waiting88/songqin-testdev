#coding=utf8

#读入file1.txt里面的内容

inputfileName='file1.txt'
outfileName='file2.txt'
with open(inputfileName) as f:
    content=f.read()


#读入所有行,记录到salarylist表格中
salarylist=content.splitlines()
print salarylist
#使用for循环，将空格去掉
with open(outfileName,'w') as f1:
    for one in salarylist:
        one=one.strip()
        #如果是空行，继续执行
        if one =='':
            continue
        if one.count(';') !=1:
            continue

        # 取出员工的名字和工资
        namepart,salarypart=one.split(';')
        name=namepart.split(':')[1].strip()
        salary=salarypart.split(':')[1].strip()
        salary=int(salary)

        #取出tax和income的值
        tax=int(salary * 0.1)
        income=int(salary*0.9)

        outStr='name:%-6s;salary:%5s;tax:%5s;income:%5s'%(name,salary,tax,income)
        print outStr
        f1.write(outStr+'\n')