#coding=utf-8
def get_salary(srcStr):
    b=srcStr.find('salary')
    c=a[b:]
    d=c.split()
    salary=int(d[1].replace("']",""))
    return salary
def  get_name(srcStr):
    b=srcStr.find('name')
    e=srcStr.find('salary')
    c=srcStr[b:e]
    d=c.split(':')
    name=d[1].replace(";","")
    name=name.replace(' ','')
    return name
with open("file1.txt",'r') as f:
#��ȡԭ�ļ���ÿ�У�����һ���б�
    line_list=f.readlines()
#ɾ�����з�
    l1=[x.strip('\n') for x in line_list]
#ÿ��Ԫ���Զ����иҲΪ��Ϊ�б���
    line_list=[x.split(',') for x in l1]
    print line_list
    name_list=list()
    salary_list=list()
    tax_list=list()
    income_list=list()
    for i in xrange(len(line_list)):
        a=str(line_list[i])
        name_list.append(get_name(a))
        salary_list.append(get_salary(a))
    tax_list=[int(x*0.1) for x in salary_list]
    income_list=[int(x*0.1) for x in salary_list]
    
	
with open("file2.txt",'w') as f2:
    new_list=list()
    for j in xrange(len(name_list)):
        new_list.append( ("name:%-9s;salary:%9d;tax:%8d;income:%9d\n" %(name_list[j],salary_list[j],tax_list[j],income_list[j])))
        print new_list
    f2.writelines(new_list)
                
            
                
	
		
		
		
		
	
	

	
	





    
