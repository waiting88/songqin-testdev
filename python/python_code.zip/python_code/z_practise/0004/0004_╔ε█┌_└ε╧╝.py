#coding=utf-8
OpenPath = 'H:/python/file1.txt'           #定义路径变量
f = open(OpenPath)
beforeTax = []
NameList = []
AllLines = f.readlines()                   #将文件中的内容全部读出
for line in AllLines:                     #依次遍历文件中的内容

    NameSalary = line.split(";")      #以分号为间隔将名字部分和工资部分分开，结果为['name: jack','  salary:   12000\n']

    Name = NameSalary[0].split(':')   #以冒号为间隔将名字部分分开，结果为['name',  '     jack ']

    Name1 = Name[1].strip()           #将['name',  ' jack ']中的元素1取出，去除名字前后的空格，结果为['jack']

    Salary = NameSalary[1].split(':')  #以冒号为间隔将工资部分分开，结果为['  salary  ',  '     1200\n ']

    Salary1 = Salary[1].strip()     #将['  salary  ',  '     1200\n ']中的元素1取出，去除工资前后的空格，结果为['12000']

    NameList.append(Name1)                   #将从文件中所获取出的名字（如'jack’）依次追加到NameList这个大列表中
    beforeTax.append(int(Salary1))           #将字符串形式的工资转化为整型形式的工资

Tax = [one * 0.1 for one in beforeTax]      #用列表表达式的形式来计算所交税额，并将其存入Tax列表中
income = [one * 0.9 for one in beforeTax]   #用列表表达式的形式来计算收入额，并将其存入income列表中

#将以上结果存入文件中：
i = 0
length = len(NameList)
SavePath = 'H:/python/FinallyFile1.txt'      #定义文件保存路径
FileSave = open(SavePath, 'w')              #以写入方式打开文件（会清空已经存在的文件）
while (i < length):
    #定义所需结果的输出形式：
    Module = 'name:%-5s  ;  salary:%-6d  ;  tax:%-5d  ;  income:%-5d\n' % (NameList[i], beforeTax[i], Tax[i], income[i])
    print Module
    FileSave.write(Module)                 #将所得结果写入文件中，需调用下面的flush()方法，否则写入失败
    FileSave.flush()                       #调用flush()方法将内容从缓冲区写入文件
    i += 1                                 #依次遍历每一条所得结果，将其全部存入文件中

