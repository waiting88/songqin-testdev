a=[('Jack   ',  12000),('Mike',  12300),('Luk ',  10030),('Tim',   9000),('John',  12000),(' Lisa',   11000)]

bf=[12000,123000,10030,9000,12000,11000]
af=[int(one*0.9) for one in bf]
af1=[int(one*0.1) for one in bf]
b=[(a[0][0],a[0][1],af1[0],af[0]),(a[1][0],a[1][1],af1[1],af[1]),(a[2][0],a[2][1],af1[2],af[2]),(a[3][0],a[3][1],af1[3],af[3]),(a[4][0],a[4][1],af1[4],af[4]),(a[5][0],a[5][1],af1[5],af[5])]
sf='''
name:%-8s;salary:%-6s;tax:%-6s;income:%-6s
name:%-8s;salary:%-6s;tax:%-6s;income:%-6s
name:%-8s;salary:%-6s;tax:%-6s;income:%-6s
name:%-8s;salary:%-6s;tax:%-6s;income:%-6s
name:%-8s;salary:%-6s;tax:%-6s;income:%-6s
name:%-8s;salary:%-6s;tax:%-6s;income:%-6s
'''
print sf % (b[0][0],b[0][1],b[0][2],b[0][3],b[1][0],b[1][1],b[1][2],b[1][3],b[2][0],b[2][1],b[2][2],b[2][3],b[3][0],b[3][1],b[3][2],b[3][3],b[4][0],b[4][1],b[4][2],b[4][3],b[5][0],b[5][1],b[5][2],b[5][3])

