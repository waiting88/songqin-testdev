#coding:utf-8
def write_file():
    fl_r=open("c:\\file1.txt","r")   
    rl1=fl_r.readlines()
    result=(line.strip().replace(" ","") for line in rl1) #去除每行内容前，后，中间的空格
    fl_r.close()

    fl_w=open("c:\\file2.txt","w")
    for i in result:
        salary=i.split(":")[2]				#获取每行中的税前薪资
        tax=str(int(int(salary)*0.1))		#计算出扣税扣掉的薪资
        income=str(int(int(salary)*0.9))	#计算出税后所得的薪资
        
        str_tax="tax:"
        str_income="income:"
        name= i.split(";")[0]
        sly_old=i.split(";")[1]
        fl_w.write("%-9s;%18s;%10s%4s;%10s%5s\n"%(name,sly_old,str_tax,tax,str_income,income))
    fl_w.close()
   
write_file()
