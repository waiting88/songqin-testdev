#encoding=utf-8

#文件操作：打开，读取
#f = open('H:/PycharmProjects/homework/file1.txt')
f_old = open('file1.txt')
f_new = open('file2.txt','w')
for fileline in f_old.readlines():
    fileline_new = fileline.split(';')
#    print fileline_new
    for i in range(len(fileline_new)):
        fileline_new_element = fileline_new[i].strip()
        file_element = fileline_new_element.split(':')
        file_element1 = file_element[0].strip()
        file_element2 = file_element[1].strip()
        if file_element1 == 'salary':
            salary = int(file_element2)
            tax = int(int(file_element2) * 0.1)
            income = int(int(file_element2) * 0.9)
            element_salary = "%10s:%10d;%10s:%10d;%10s:%10d" % ('salary',salary,'tax',tax,'income',income)
        elif file_element1 == 'name':
            element_name = "%s:%10s;" % (file_element1,file_element2)
    fileline_new =  '%s;%s' % (element_name,element_salary)
    f_new.write(fileline_new+'\n')
f_new.close()
f_old.close()