#encoding=utf-8
#文件操作：打开，读取
#f = open('H:/PycharmProjects/homework/file1.txt')
f_old = open('file1.txt')
f_new = open('file2.txt','w')
for fileline in f_old.readlines():
    filelinenew = fileline.split(';')
    filelinenew_name = filelinenew[0]
    filelinenew_salary = filelinenew[1]
    filelinenew_element1 = filelinenew_name.strip()
    filelinenew_element2 = filelinenew_salary.strip()
    fileelement_name = filelinenew_element1.split(':')
    fileelement_sary = filelinenew_element2.split(':')
    fileelement_name1 = fileelement_name[0].strip()
    fileelement_name2 = fileelement_name[1].strip()
    fileelement_salary1 = fileelement_sary[0].strip()
    fileelement_salary2 = fileelement_sary[1].strip()
    salary = int(fileelement_salary2)
    tax = int(int(fileelement_salary2) * 0.1)
    income = int(int(fileelement_salary2) * 0.9)
    element_salary = "%10s:%10d;%10s:%10d;%10s:%10d" % ('salary',salary,'tax',tax,'income',income)
    element_name = "%s:%10s" % (fileelement_name1,fileelement_name2)
    fileline_new = '%s;%s' % (element_name,element_salary)
    f_new.write(fileline_new+'\n')
f_new.close()
f_old.close()