def salary():
    with open("F:/file1.txt","r+") as fp:
        f = fp.readlines()
        tax = []
        income = []
        name = []
        salary1 = []


        for i in f:
            i = i.strip('\n')
            i = i.split(';')
            salary1.append(i[1])


        for i in f:
            i = i.strip()
            i = i.split(';')
            name.append(i[0])

        salary2 = []
        for j in salary1:
            j = j.strip()
            j = j.split(':')
            salary2.append(int(j[1]))


        tax = [one*0.1 for one in salary2]
        incom = [one*0.9 for one in salary2]

        with open("F:/a.txt","w+") as sp:
            for i in range(len(name)):
                sp.write( " %-10s;  %-5s:%5s;   tax:%5s;   incom:%5s \n " %(name[i],"salary",salary2[i],int(tax[i]),int(incom[i])))




salary()