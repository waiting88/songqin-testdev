# coding: utf-8
fileopen = open('C:\Users\New\Desktop\\file1.txt')
while True:

    line = fileopen.readline().strip().split(";")
    Name = line[0].rstrip()
    Salary = line[1].lstrip()
    line_1 = Name + " ;" + Salary

    Num = Salary.find(':')
    salary = int(Salary[Num+1:])
    tax = salary - salary * 0.9
    income = salary * 0.9
    newline = line_1 + '; tax:%5d ; income:%6d'%(tax,income)
    print newline
    file2 = open('D:/file2.txt','r+')
    file_2 = file2.write(newline)
    print file2.read()
    file2.close()
fileopen.close()
#本次执行的结果有个越界报错，可能是文件里面有空白行，但是调试了代码，仍然没有解决






