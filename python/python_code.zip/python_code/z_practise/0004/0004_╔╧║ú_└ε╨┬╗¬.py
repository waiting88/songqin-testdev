path1=r"C:\Users\ody\Desktop\file1.txt"
path2=r"C:\Users\ody\Desktop\file2.txt"
file1=open(path1,'r')
lines=file1.readlines()
for line in lines:
    name=line.split(';')[0].split(':')[0]
    salary=int(line.split(';')[1].split(':')[1])
    tax=salary*0.1
    income=salary*0.9
    print name,salary,tax,income
    open(path2,'a').writelines("name:%6s;salary:%10d;tax:%5d;income:%10d\n" %(name,salary,tax,income))
    
    
