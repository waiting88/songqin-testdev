with open('file1.txt') as f:
    lines=f.readlines()
with open('file2.txt','w') as wf:
    for i in range(0,len(lines)):
        newtxt=[]
        newlines =lines[i].strip().split(';')
        nameList=newlines[0].strip().split(':')
        name=nameList[-1].strip()  
        salarys=newlines[-1].strip()
        salary=salarys.strip().split(':')
        salary=salary[1].strip()   
        income=int(int(salary)*0.9)  
        tax=int(salary)-int(income)  
        wf.write('name: {:<10};salary: {:<10};tax: {:<10};income: {:<10}\n'.format(name,salary,income,tax))
