# coding=utf8


#读入文件内容到变量 content
#将 每有效行 ， 记录到列表 salaryList 里
inputFileName = 'file1.txt'
outFileName = 'file2.txt'

with open(inputFileName) as f:
    content = f.read()

salaryList = content.splitlines()

# 对于salaryList 里面的每条记录：

with open(outFileName,'w') as f:

    for one in salaryList:
        one = one.strip()
        # 如果是空行，跳过
        if one == '':
            continue

        # 目前该行格式 这样  'name: Jack Jone  ;    salary:  12000'
        if one.count(';') != 1:
            continue
        # 取出员工姓名 和 税前工资
        namepart,salarypart = one.split(';')
        name = namepart.split(':')[1].strip()
        salary = salarypart.split(':')[1].strip()
        salary = int(salary)

        #     计算 税后工资
        tax    = int(salary *0.1)
        income = int(salary *0.9)

        #     格式化输出
        outStr = 'name: %10s;    salary: %5s;  tax: %5s; income:  %5s' % (name,salary,tax,income)
        print outStr
        f.write(outStr + '\n')

