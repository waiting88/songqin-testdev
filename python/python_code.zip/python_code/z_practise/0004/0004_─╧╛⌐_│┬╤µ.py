##################################################################################
#encoding:utf-8
'''现有文件1（见附件 file1.txt）， 记录了公司员工的薪资，其内容格式如下
name: Jack   ;    salary:  12000
 name :Mike ; salary:  12300
name: Luk ;   salary:  10030
  name :Tim ;  salary:   9000
name: John ;    salary:  12000
name: Lisa ;    salary:   11000
每个员工一行，记录了员工的姓名和薪资， 每行记录 原始文件中并不对齐，中间有或多或少的空格
现要求实现一个python程序，计算出所有员工的税后工资（薪资的90%）和扣税明细，以如下格式存入新的文件2中，如下所示
name: Jack   ;    salary:  12000 ;  tax: 1200 ; income:  10800
name: Mike   ;    salary:  12300 ;  tax: 1230 ; income:  11070
name: Luk    ;    salary:  10030 ;  tax: 1003 ; income:   9027
name: Tim    ;    salary:   9000 ;  tax:  900 ; income:   8100
name: John   ;    salary:  12000 ;  tax: 1200 ; income:  10800
name: Lisa   ;    salary:  11000 ;  tax: 1100 ; income:   9900'''
##################################################################################
'''
list = [['name: Jack   ;    salary:  12000'],
['name :Mike ; salary:  12300'],
['name: Luk ;   salary:  10030'],
['  name :Tim ;  salary:   9000'],
['name: John ;    salary:  12000'],
['name: Lisa ;    salary:   11000']]'''

with open('file1.txt','r') as f1:
    list = f1.readlines()
    f2 = open('file2.txt', 'w')
    for oneline in list:
        a = oneline.split(';')
        b = a[0].split(':')
        name = b[1].strip()
        c= a[1].split(':')
        salary = c[1].strip()
        tax = int(int(salary) * 0.1)
        income = int(int(salary) * 0.9)
        #print 'name: {:<7};    salary:{:>7} ;  tax:{:>6} ; income:{:>7}'.format(name,salary,tax,income)
        f2.write('name: {:<7};    salary:{:>7} ;  tax:{:>6} ; income:{:>7}\n'.format(name,salary,tax,income))
    f2.close()