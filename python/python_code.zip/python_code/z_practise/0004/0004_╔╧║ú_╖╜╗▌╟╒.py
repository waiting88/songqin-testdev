#!/usr/bin/env python
# -*- coding: utf-8 -*-
#作业二
with open('C:\\Users\\Administrator\\PycharmProjects\\untitled1\\file1.txt','r') as f:
    text = f.read().split('\n')
    for txt in text:
        names = txt.split(';')[0]
        name = names.split(':')[1]
        salarys = txt.split(';')[1]
        salary = salarys.split(':')[1]
        tax = int(int(salary) * 0.1)
        income = int(salary) - int(tax)
        text1 = '''name: %-5s ;  salarys: %6s ;  tax: %5s ;  income: %6s''' % (name.strip(), salary.strip(), tax, income)

        f = open('C:\\Users\\Administrator\\PycharmProjects\\untitled1\\file2.txt','a+')
        f.write(text1 + '\n')
        f.close()
