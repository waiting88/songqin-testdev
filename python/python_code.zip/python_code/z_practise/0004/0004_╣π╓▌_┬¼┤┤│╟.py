#coding=utf-8
#思路：把名字和薪资提取出来，构造一个新的文件
f=open('file1.txt','r')                #当前目录打开文件file1.txt
nf=open('file2.txt','a')
for i in f:
    a=i.split(';')
    name=a[0].split(':')[1].strip()     #提取名字
    salary=a[1].split(':')[1].strip()   #提取薪资
    tax=int(salary)/10                  #扣税明细
    income=int(salary)*9/10             #实得薪资
    N='name: '+'{:<7s}'.format(name)
    S='    salary:'+'{:>7s}'.format(salary)
    T='  tax:'+'{:>6d}'.format(tax)
    I=' income:'+'{:>7d}'.format(income)
    line=N+';'+S+';'+T+';'+I+'\n'
    nf.write(line)                       #不清空文件写入新文件file2.txt
f.close()
nf.close()
