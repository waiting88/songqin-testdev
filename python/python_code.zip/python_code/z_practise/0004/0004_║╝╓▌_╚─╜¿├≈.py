# coding=utf-8
with open('file1.txt') as f1:
    with open('file2.txt','w+') as f2:
        for one in f1.readlines():
            one=one.replace(' ','')# 去除空格
            one=one.replace('\n','')#去除"\n"换行符
            datalist =one.split(':')#把每行的数据分割成列表
            salary = datalist[-1]
            datalist.append(int(float(salary)*0.1))#计算tax并转换成整型
            datalist.append(int(float(salary) * 0.9))#计算income并转换成整型
            newline=datalist[0]+":"+datalist[1]+":"+salary+"tax:"+";"+str(datalist[2])+";"+"income:"+str(datalist[3])
            print >>f2,newline #新数据写入到file2中