# coding=utf-8
with open(u'C:/Users/Administrator/Desktop/cfiles/gbk编码.txt') as f:
    techAge1 = f.read().decode('gbk')

with open(u'C:/Users/Administrator/Desktop/cfiles/utf8编码.txt') as f:
    techAge2 = f.read().decode('utf-8')

    techAge = techAge1 + '\n' + techAge2

userInput=raw_input('请输入新文件名字：')
a ='C:/Users/Administrator/Desktop/' + userInput.decode('gbk') + '.txt'

with open(a,'w') as f:
   f.write(techAge.encode('utf-8'))

