#coding:utf-8


filename = "F:/cfiles/gbk编码.txt".decode("utf-8")
with open(filename) as fp:
    content1 = fp.read().decode("gbk")
    print content1

file = "F:/cfiles/utf8编码.txt".decode("utf-8")
with open(file) as ff:
    content2 = ff.read().decode("utf8")
    print content2
content = content1+" "+content2
print content

filename2 = raw_input(u"请输入新文件的名称：").encode("utf-8")
with open(filename2,"w") as fm:
    content = content.encode("utf-8")
    fm.write(content)

