#coding=utf-8
contant = []
fh1 = open(u'C:\\files\gbk编码.txt')
Fileone = fh1.read()
fh1.close()
uc1 = Fileone.decode('gbk')
#print uc1
contant.append(uc1)

fh2 = open(u'C:/cfiles/utf8编码.txt')
Filetwo = fh2.read()
fh2.close()
uc2 = Filetwo.decode('utf8')
#print uc2
contant.append(uc2)
#print contant

for one in contant:
    print one



raw_input(u'请输入编码文件：')
with open(u'C://cfiles//编码文件.txt','w') as fh3:
    for one in contant:
        fh3.write(one.encode('utf8'))