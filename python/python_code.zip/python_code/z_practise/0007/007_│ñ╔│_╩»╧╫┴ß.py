# coding=utf-8
#将“gbk编码.txt”文件读出，解码成Unicode，并显示出来
with open(u'cfiles/gbk编码.txt') as f:
    b = f.read()
    # print type(b)
    uc = b.decode('gbk') #将gbk编码解码成Unicode编码
    print (u'gbk编码文件读出的内容是:%s') % uc
    # print type(uc)

#将“utf8编码.txt”文件读出，解码成Unicode，并显示出来
ab = open(u'cfiles/utf8编码.txt') #将文件名转换成Unicode编码读入
abstr = ab.read() #将字符串读入文件
# print abstr
# print type(abstr)
ud = abstr.decode('utf-8') #将文件内容字符串（utf8编码）解码成Unicode
print (u'utf8编码文件读出的内容是:%s') % ud
# print type(ud)

########################################################################
#方式一
#filelist = [uc, ud] #将字符放到一个list中
#t = raw_input(u'请输入新文件的名称:').decode('utf-8')+'.txt' #接收raw_ipnut输入的字符串并解码为Unicode，再拼接.txt
#print type(t)
#wfile = open(t, 'w')  # 创建.txt文件，准备写入

# 用for循环字符遍历并写入到文件
#for x in filelist:
    #wfile.write(x.encode('utf-8')) #将遍历项x的内容已utf-8的编码
    #print x #输出txt文件内容
#wfile.close()
#######################################################################

#方式二
j = uc+ud
print (u'文件合并后的内容是:%s') % j
t = raw_input(u'请输入新文件的名称:').decode('utf-8')+'.txt'
#print type(t)
#fh = open (t,'w')
#fh.write(j.encode('utf-8'))
#fh.close()

#用with open的方式
with open(t,'w') as g:
    g.write(j.encode('utf-8'))  #用utf-8编码写入文件中
    g.close()
