# -*- coding: UTF-8 -*-
__author__ = 'fjj'
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
__author__ = 'fjj'
FirstPath = "E:\\panda\\cfiles\\gbk编码.txt".decode("utf-8")
SecondPath="E:\\panda\\cfiles\\utf8编码.txt".decode("utf-8")
with open(FirstPath,'r') as f1:
    context_1=f1.readline()
    line1=context_1.decode('gbk')
with open(SecondPath,'r') as f2:
    context_2=f2.readline()
    line2=context_2.decode('utf8')
line=line1+' '+line2
print line
NewFileName=raw_input('请输入新文本的名称:').decode("utf-8")
Filename=NewFileName
with open(NewFileName,'w') as f:
    f.write(line)

