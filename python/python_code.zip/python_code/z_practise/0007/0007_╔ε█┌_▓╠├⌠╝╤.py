#coding=utf-8
'''
解压该压缩包，里面 包含了两个文件。 一个叫 &#39;gbk编码.txt&#39;, 该文件是gbk编码的。另一个文件叫 &#39;utf8编码.txt&#39;, 该文件是utf8编码的。 两个文件里面的内容都包含中文。
要求大家编写一个python程序，该程序做到以下几点
   1. 将两个文件内容读出， 合并内容到一个字符串中， 并能用print语句将合并后的内容正确显示
   2. 合并后的内容输出到一个新文件中，以utf8格式编码。新文件的文件名是在程序运行时， 先用中文提示用户“请输入 新文件的名称”，用户输入文件名可以包含中文
请大家实现该python程序，存在文件名为 0007_城市_名字 (比如 0005_深圳_李霞.py )的文件中， QQ发给江老师
'''
with open(u"gbk编码.txt",'r') as f1:
     content1=f1.read()
     content1.decode('gbk')
     print content1

with open(u'utf8编码.txt','r') as f2:
     content2=f2.read()
     content2.decode('utf-8')
     print content2
str=('%s%s' %(content1.strip('\n'),content2.decode('utf-8').encode('gbk')))
str=str.decode('gbk','ignore')
print str
print u"请输入新文件的名称"
filename=raw_input(':')
try:
    filename=filename.decode('utf-8')
except Exception as e:
    filename=filename.decode('gbk')
finally:
    f3=open(filename,'w')
    f3.write(str.encode('utf-8'))
    f3.close()
    
