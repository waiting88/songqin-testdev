#encoding=utf8
with open(u'cfiles/gbk编码.txt') as f:
    li1=f.read().decode('gbk')
with open(u'cfiles/utf8编码.txt')as h:
    li2=h.read().decode('utf-8')
a=raw_input('请输入新文件的名称:').decode('utf-8')
with open(u'a.txt','w')as k:
    nameage=li1+li2
    print nameage
    k.write(nameage.encode('utf-8')+'\n')