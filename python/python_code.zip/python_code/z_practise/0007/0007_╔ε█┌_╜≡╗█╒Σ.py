#coding=utf-8
import os

with open(('cfiles\gbk编码.txt').decode("utf-8")) as f1:
	s1 = f1.read().decode('gbk' )
with open(unicode(('cfiles\utf8编码.txt'),("utf-8"))) as f2:
	s2 = unicode(f2.read(),'utf-8')
print 's :',s1+' '+s2
s=s1 +' '+ s2
while(True):
	a = '请输入新文件的名称:'
	filename = raw_input(a)
	#filename = raw_input(unicode(a, 'utf-8').encode('gbk'))
	try:
		f = open(filename, 'w+')
		f.write(s.encode('utf-8'))
		break
		f.close()

	except IOError:
		print '文件名中包含非法字符！请重新输入'
		continue