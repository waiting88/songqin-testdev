# coding=utf-8
#open utf8file
filePath1="H:/python/cfiles/utf8编码.txt"
utfpath=filePath1.decode('utf8')
print utfpath
print type(utfpath)
with open(utfpath) as f1:
     utfContent=f1.read().decode('utf8')
     print type(utfContent)
     print utfContent

#open gbkfile
filePath2="H:/python/cfiles/gbk编码.txt"
gbkpath=filePath2.decode('utf8')
print gbkpath
print type(gbkpath)
with open(gbkpath) as f2:
     gbkContent=f2.read().decode('gbk')
     print type(gbkContent)
     print gbkContent


#combine two files to  output to a newfile
print 'two files become a newfile:'
content = utfContent + '\n' + gbkContent
print content
print type(content)

#print u'请输入一个新文件名：'
Name = raw_input('请输入一个新文件名：')
fileName = Name.decode('utf8')
newfileName = fileName + ".txt"

print newfileName
with open (newfileName,'w') as f3:
    f3.write(content.encode('utf8'))
    f3.flush()

