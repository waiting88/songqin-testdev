# coding:utf-8
with open(u"c:\\gbk编码.txt") as f1:
    rlt = f1.read()
    rlt1=rlt.decode("gbk")
with open(u"c:\\utf8编码.txt") as f1:
    rlt = f1.read()
    rlt2=rlt.decode("utf8")
result=rlt1+' '+rlt2
print result
input_value=raw_input(u"请输入文件名称：")
input_value=input_value.decode("utf8")
filename='c:\\'+input_value+'.txt'
fl_new=open(filename,'w')
fl_new.write(result.encode('utf-8'))