#coding:utf-8

import codecs
def code_test():
    fpath = 'C:\Users\New\Desktop\cfiles\utf8编码.txt'
    print type(fpath)
    upath = fpath.decode('utf8')
    print type(upath)
    with open(upath) as f:
        utf8content = f.read()
        print utf8content,type(utf8content)

    Fpath = 'C:\Users\New\Desktop\cfiles\gbk编码.txt'
    gpath = Fpath.decode('utf8')
    print type(gpath)
    with open(gpath) as F:
        Content = F.read()
        gbkcontent = Content.decode('gbk').encode('utf8')
        print gbkcontent,type(gbkcontent)
    newcontent = utf8content + ',' +gbkcontent
    print newcontent


    print u"请输入新的文件路径及名称："
    filename = raw_input(u'>')
    ufilename = filename.decode('utf8')
    with open(ufilename,'w') as newf:
        newfile = newf.write(newcontent)
    return newfile

code_test()