#coding=utf8
#里面 包含了两个文件，一个叫gbk编码.txt，该文件是gbk编码的。另一个文件叫utf8编码.txt;该文件是utf8编码的。 两个文件里面的内容都包含中文。
#1. 将两个文件内容读出， 合并内容到一个字符串中， 并能用print语句将合并后的内容正确显示
path1=u"C:\\Python27\\\cfiles\\cfiles\\gbk编码.txt"
path2=u"C:\\Python27\\cfiles\\cfiles\\utf8编码.txt"
f1=open(path1)
f2=open(path2)
str1=f1.read().decode('gbk')
str2=f2.read().decode('utf-8')
f1.close()
f2.close()
str1+=str2
print str1
# 2. 合并后的内容输出到一个新文件中，以utf8格式编码。新文件的文件名是在程序运行时， 先用中文提示用户“请输入 新文件的名称”，用户输入文件名可以包含中文
filename=raw_input(u'请输入新文件的名称 \n')
filename="c:/python27/"+filename+".txt"
f3=open(filename,'w')
f3.write(str1.encode('utf-8'))
f3.close()