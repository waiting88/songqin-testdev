# -*- encoding: utf-8 -*-

with open(u'utf8编码.txt') as f:

    file1 = f.read().decode('utf-8')
    
with open(u'gbk编码.txt') as h:

    file2 = h.read().decode('gbk')

print file1+file2

    
newFile = raw_input('fileName:')
f = open(newFile,'w')
f.write(file1.encode('utf-8'))
f.write(file2.encode('utf-8'))
f.close()
with open (newFile) as new:
    print new.read().decode('utf-8')

