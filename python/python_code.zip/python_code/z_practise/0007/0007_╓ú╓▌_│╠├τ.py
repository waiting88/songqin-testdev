#coding=utf8

#读取出文件gbk编码.txt里面的内容
with open(u'gbk编码.txt') as f1:
    bcstr1=f1.read()                  #str类型
f1.close()
uc=bcstr1.decode('gbk')              #将文件解码
print uc
#读取出文件utf8编码.txt里面的内容
with open(u'utf8编码.txt') as f2:
    bcstr2=f2.read()                   #str类型
f2.close()
uc2=bcstr2.decode('utf8')             #将文件解码
print uc2
#将两个字符串合并在一个字符串中
newuc=uc+' '+ uc2
print newuc                           #用print语句将合并后的内容打印出来

#将合并后的文件输入到新的文件中

file=open(u'newfile','w')           #打开这个新文件，给予写的权限
file.write(newuc.encode('utf8'))     #输出成指定的utf8格式
file.close()                           #关闭这个文件

#打开新的文件
with open(u'newfile') as f:
   content=f.read()
print content                          #打印出新文件读取的内容
content=raw_input(u'请输入新文件的名称：')

#备注：新文件的文件名是在程序运行时， 先用中文提示用户“请输入 新文件的名称”，
       # 用户输入文件名可以包含中文
       #这个不太会

