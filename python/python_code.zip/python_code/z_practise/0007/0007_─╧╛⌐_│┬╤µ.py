##encoding=utf8
# 解压该压缩包，里面 包含了两个文件。
# 一个叫“gbk编码.txt”, 该文件是gbk编码的。另一个文件叫“utf8编码.txt”, 该文件是utf8编码的。
#  两个文件里面的内容都包含中文。
# 要求大家编写一个python程序，该程序做到以下几点
#   1. 将两个文件内容读出， 合并内容到一个字符串中， 并能用print语句将合并后的内容正确显示
#   2. 合并后的内容输出到一个新文件中，以utf8格式编码。
# 新文件的文件名是在程序运行时， 先用中文提示用户“请输入 新文件的名称”，用户输入文件名可以包含中文


with open(u'cfiles/gbk编码.txt','r') as f1:
    str1 = f1.read().decode('gbk')
with open(u'cfiles/utf8编码.txt','r') as f2:
    str2 = f2.read().decode('utf8')
str = str1 + str2
print str
print u'请输入新的文件名称：'
fileName = raw_input()
try:
    fileName = fileName.decode('utf8')
except UnicodeDecodeError:
    fileName = fileName.decode('gbk')
#else:
with open(fileName+'.txt','w') as f3:
    f3.write(str.encode('utf8'))