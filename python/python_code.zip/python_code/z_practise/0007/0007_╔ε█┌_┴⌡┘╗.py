with open(u'cfiles\\gbk编码.txt') as f:
    gbStr=f.read()
    uc=gbStr.decode('gbk')
with open(u'cfiles\\utf8编码.txt') as fh:
    utfStr=fh.read()
    uc1=utfStr.decode('utf')
newStr = uc+'\n'+uc1
print('请输入新文件的名称:')
newFileName=raw_input().decode('utf-8')
with open(u'%s.txt'%(newFileName),'w') as wf:
    wf.write(newStr.encode('utf-8'))