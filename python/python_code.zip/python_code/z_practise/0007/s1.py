# coding=utf8

with open(u'cfiles/gbk编码.txt') as f1, open(u'cfiles/utf8编码.txt') as f2:
    content1 = f1.read().decode('gbk')
    content2 = f2.read().decode('utf8')

    newContent = content1 + content2

    print newContent

print u'请输入文件名称：',
nfilename = raw_input()

import sys
print sys.stdin.encoding

nfilename = nfilename.decode(sys.stdin.encoding)


with open(nfilename,'w') as fileHandle:
    fileHandle.write(newContent.encode('gbk'))