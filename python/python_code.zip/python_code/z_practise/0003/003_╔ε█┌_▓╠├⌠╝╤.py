def list_sort(l):
	new_list=[]
	for i in xrange( len(l)-1, 0, -1):
		for j in xrange(i):
			if l[j] > l[j+1]:
				l[j], l[j+1] = l[j+1], l[j]
	for k in xrange(0,len(l)):
		new_list.append(l[k])
	print new_list
	return new_list
	
   



   


				
 

    

