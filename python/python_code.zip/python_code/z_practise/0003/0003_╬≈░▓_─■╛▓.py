

oldlist = [2,3,5,8,1,4,7,6]
newlist = []
while len(oldlist) > 0:
    minnum = min(oldlist)
    newlist.append(minnum)
    oldlist.remove(minnum)
print newlist