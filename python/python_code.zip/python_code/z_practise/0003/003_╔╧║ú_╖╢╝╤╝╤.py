# -*- coding: UTF-8 -*-
__author__ = 'fjj'
student_info = raw_input('请输入学生信息:')
student_info_1 = student_info.split(';')  # 以；分割


def fool(x):  # 以，分割 并且返回一个完整的列表
    l = []
    for i in range(len(x)):
        y = x[i].split(',')
        if len(y) > 1:
            l.extend(y)
    return l


l_1 = fool(student_info_1)  # 列表重新赋值，备用
m = []
length = len(l_1)
for j in range(length):
    m.append(l_1[j].strip())  # 去列表里元素首尾空格，重组列表
for k in range(len(m)):
    if k % 2 == 0:
        if len(m[k]) > 20:
            print '此次输入"%s"姓名长度大于20,请重新输入！' % m[k]
            break
        m[k + 1] = int(m[k + 1])
        print '%-10s:%02d;' % (m[k], m[k + 1])  # 位置固定，隔1选1，格式化输出
