#encoding:utf-8
#请实现一个函数，参数为一个list，list中的元素都是整数，函数需要将List中的元素按从小到大排序，最终返回一个新的list。
#请按下面算法的思路实现函数：
#创建一个新的列表newList
#先找出所有元素中最小的，append在newList里面
#再找出剩余的所有元素中最小的，append在newList里面
#依次类推，直到所有的元素都放到newList里面






def list(list):
    newlist = []
    for i in range(len(list)):
        a = list.index(min(list))    #最小数索引
        newlist.append(list.pop(a))
    return newlist


#调试函数
#a = [5,32,356,3,25,95,83,15,2,17]
#b = list(a)
#print b


