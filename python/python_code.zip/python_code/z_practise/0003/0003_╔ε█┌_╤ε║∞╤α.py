#coding=utf-8
'''请实现一个函数，参数为一个list，list中的元素都是整数，函数需要将List中的元素按从小到大排序，最终返回一个新的list。
请按下面算法的思路实现函数：
创建一个新的列表newList
先找出所有元素中最小的，append在newList里面
再找出剩余的所有元素中最小的，append在newList里面
依次类推，直到所有的元素都放到newList里面  '''
oldList=[23,5,53,1,45,5,7,6,21,11,53]
newList=[]
i=0
while i<len(oldList):
       minNume=min(oldList)
       newList.append(minNume)
       oldList.remove(minNume)
print newList
