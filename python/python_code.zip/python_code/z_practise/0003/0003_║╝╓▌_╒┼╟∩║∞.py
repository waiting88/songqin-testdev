def paixu(list):
    
    newlist=[]
    for i in range(len(list)-1,0,-1):
        for j in range(0,i):
            if list[j] < list[j+1]:
                list[j],list[j+1]  = list[j+1],list[j]
        newlist.append(list[i])
    newlist.append(max(list))
        
    print newlist
    return newlist   
        
        
paixu([10,5,88,23,21,56])
            

        
        
    
    