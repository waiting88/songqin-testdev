def maxsort(list):
    newlist = []
    for j in range(len(list)-1,0,-1):
        for i in range(0,j):
            if list[i] < list[i+1]:
                list[i],list[i+1] = list[i+1],list[i]
            if i+1 == j :
                newlist.append(list[i+1])   
    newlist.append(list[0])        
    return newlist

    
def smallsort(list):
    newlist = []
    for j in range(len(list)-1,0,-1):
        for i in range(0,j):
            if list[i] < list[i+1]:
                list[i],list[i+1] = list[i+1],list[i]
            if i+1 == j :
                newlist.append(list[i+1])    
    newlist.append(list[0])        
    newlist.reverse()
    print newlist
list = [3,5,2,6,9,7,3]
print maxsort(list)
print smallsort(list)