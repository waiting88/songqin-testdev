oldlist = [2,22,78,55,10,56,22,100]
newlist = []
Len = len(oldlist)
i = 0
while i <  Len:
    elemax = max(oldlist)
    oldlist.remove(elemax)
    newlist.append(elemax)
    i = i + 1
print newlist