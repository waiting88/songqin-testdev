#coding=utf-8
def NewList(list):
    newList=[]
    for x in range(len(list)):
            for i in range(len(list)):
                a=min(list)
                newList.append(a)
                del list[list.index(a)]
    return newList
aa=[523,8,6,1,7,456,0,2,96,88,7]
print NewList(aa)