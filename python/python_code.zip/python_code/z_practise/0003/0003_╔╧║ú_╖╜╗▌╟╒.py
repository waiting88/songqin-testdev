#!/usr/bin/env python
# -*- coding: utf-8 -*-

#作业一

def STLlist(list):
    newlist = []
    for j in range(len(list) - 1, 0, -1):
        minnum = list[j]
        for i in range(0, j, 1):
            if minnum > list[i]:
                minnum = list[i]
            i += 1
        newlist.append(minnum)
        list.remove(minnum)
        j -= 1
    minnum = list[0]
    newlist.append(minnum)
    return newlist
'''
list = [9, 10, 8, 12, 1, 0, 7, 4, 3, 2]
newlist = STLlist(list)
print newlist
'''


