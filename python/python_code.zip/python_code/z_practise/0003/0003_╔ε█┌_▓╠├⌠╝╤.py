def list_sort(List):
    new_list=[]  
    list_length=len(List)  
    for i in range(0,list_length-1):  
        for j in range(i+1,list_length-1):  
            if List[i]>List[j]:  
                List[i],List[j]=List[j],List[i]
        new_list.append(List[i])
    print   new_list     
    return  new_list

