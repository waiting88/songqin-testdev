def Listsort(list):
    newList = []
    listCopy = []
    for r in list:
        listCopy.append(r)
    for i in range(len(listCopy)):
        Min = listCopy[i]
        for j in range(i+1,len(listCopy)):
            if  Min> listCopy[j]:
                tmp = Min
                Min = listCopy[j]
                listCopy[j]=tmp
            j = j + 1
        newList.append(Min)
        if Min > listCopy[i]:
            tmp = Min
            Min = listCopy[j]
            listCopy[j]=tmp
        i = i + 1
    return newList

list = [2,5,8,3,6,0,4]
print Listsort(list)
print list

