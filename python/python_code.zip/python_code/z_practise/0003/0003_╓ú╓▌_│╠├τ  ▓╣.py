#coding=utf8
#创建一个函数
def intlist(inlist):
    newlist=[]

    #使用循环,找出当前inlist中所有元素中最小的curmin
    while len(inlist)>0:
        themin=inlist[0] #指明当前元素最小的值
        idx=0 #指向当前元素下标
        minidx=0 #记录当前最小元素的下标
        #遍历当前循环中最小的元素
        for one in inlist:

            if themin >one:
                themin=one
                minidx=idx
            idx +=1

        inlist.pop(minidx)
        newlist.append(themin)
    return newlist
print intlist([2,4,1,56,23,1,34])


