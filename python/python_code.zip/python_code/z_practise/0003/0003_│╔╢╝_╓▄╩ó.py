def rank_number(list):
    newList = []
    while list != []:
        one = min(list)
        newList.append(one)
        list.remove(one)
    print newList
list = [1,4,6,8,3,2,5,7]    
rank_number(list)    