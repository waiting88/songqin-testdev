# coding:utf-8
def list_order():
    list_1 = [44, 33, 66, 22, 3, 6, 8, 5, 9, 1, 7, 35, 42]
    new_list = []
    while list_1 != []:

        min_number = min(list_1)
        new_list.append(min_number)
        list_1.remove(min_number)

    print new_list

list_order()
#for min_number in list_1:
# 用for循环只得到了【1,3,5,6,7,8,9】剩下的两位数的没有被循环比较进来，没找到为啥，这是本次作业的一个问题