# coding=utf-8
def sort(alist):
      for i in range(0,len(alist),1):
        for j in range(0,len(alist)-1,1):
            if alist[j]<alist[j+1]:
               alist[j+1],alist[j] = alist[j],alist[j+1]# 若前一个数小于后一个数则交换位置
        newlist.append(alist.pop(len(alist)-1))# 把排序后的小元素从alist中删除并添加到newlsit中
newlist = []
b = [0,4,2,6,7,5,9,12,5,1,22]
sort(b)
print newlist