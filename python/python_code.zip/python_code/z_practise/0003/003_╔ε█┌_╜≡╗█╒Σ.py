oldList=[3,5,7,2,56,34,54,23,21,56,33,2]
newList=[]

def L_sort(newList):
	for j in range(0,len(oldList)):
		for i in range(j+1,len(oldList)):
			if oldList[i] < oldList[j]:
				oldList[j],oldList[i]=oldList[i],oldList[j]

		newList.append(oldList[j])
	print ('oldList = %s'% oldList)
	return (newList)

print L_sort(newList)