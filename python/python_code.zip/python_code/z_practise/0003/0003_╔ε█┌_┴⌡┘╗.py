def rank(aList):
    newList=[]
    for i in range(0, len(aList)):
        for j in range(i + 1, len(aList)):
            if aList[i] > aList[j]:
                min=aList[j]
            else:
                min=aList[i]
    newList.append(min)
    print newList
    
    
rank([3,4,55,6,4,3,2,1])    