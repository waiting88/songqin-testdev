def px(list):
	newList = []
	for j in range(0,len(list)-1,1):
		for i in range(j+1,len(list),1):
			if list[j]>list[i]:
				list[j],list[i]=list[i],list[j]
		newList.append(list[j])
	print newList