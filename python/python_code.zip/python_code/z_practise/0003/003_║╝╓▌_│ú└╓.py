def num(list1):
    
    lenght=len(list1)
    newList=[]
    for i in range(0,lenght):
        result=min(list1)
        newList.append(result)
        list1.remove(result)
    return newList

list1=[1,3,5,9,7,9,8,20,15,17,0,99,35,27,28]
num(list1)


