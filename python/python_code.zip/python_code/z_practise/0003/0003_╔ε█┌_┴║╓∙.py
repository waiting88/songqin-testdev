def ordering(oldList):     
    elementNum = len(oldList)   
    for i in range(0,elementNum):         
        for j in range(i+1,elementNum):       
            if oldList[i] > oldList[j]:          
                oldList[i],oldList[j] = oldList[j],oldList[i]               
    return oldList
    
oldList = [6,3,5,6,67,8]
newList = ordering(oldList)
print 'newList=' + str(newList)

 
