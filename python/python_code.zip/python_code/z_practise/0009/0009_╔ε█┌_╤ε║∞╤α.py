#coding=utf-8
#coding=utf-8
'''***** 编程题 0009 ******
要求大家用面向对象的设计编写一个python程序，实现一个文字游戏系统。
动物园里面有10个房间，房间号从1 到 10。
每个房间里面可能是体重200斤的老虎或者体重100斤的羊。
游戏开始后，系统随机在10个房间中放入老虎或者羊。
然后随机给出房间号，要求游戏者选择敲门还是喂食。
如果选择喂食：
喂老虎应该输入单词 meet，喂羊应该输入单词 grass
喂对了，体重加10斤。 喂错了，体重减少10斤
如果选择敲门：
敲房间的门，里面的动物会叫，老虎叫会显示 ‘Wow !!’,羊叫会显示 ‘mie~~’。 动物每叫一次体重减5斤。
游戏者强记每个房间的动物是什么，以便不需要敲门就可以喂正确的食物。
游戏3分钟结束后，显示每个房间的动物和它们的体重。
实现过程中，有什么问题，请通过课堂上讲解的调试方法，尽量自己发现错误原因。'''
class Animal:
    def __init__(self,animaltype):
        self.animaltype = animaltype
        if self.animaltype == "tiger":
            self.weight = 200
            self.roar="wow!!!"
        else:
            self.weight=100
            self.roar="mie~~~"
    def eatfood(self,food):
        if self.animaltype=="tiger":
            if food=="meet":
                print "喂对了，长了十斤肉，胖啦！胖啦！"
                self.weight+=10
            else:
                print "喂错了，减了十斤肉，瘦啦！瘦啦！"

        else:
            if food=="meet":
                print "喂对了，长了十斤肉，胖啦！胖啦！"
                self.weight+=10
            else:
                print "喂错了，减了十斤肉，瘦啦！瘦啦！"
    def animalroar(self):
        if self.animaltype=="tiger":
            print "wow!!!"
        else:
           print "mie~~~"
import random
from random import randint
import time
animaldict={}
i=1
while i<11:
    name=random.choice(["tiger", "sheep"])
    animaldict[i]=Animal(name)
    i+=1
print animaldict
starttime=time.time()
while True:
    endtime=time.time()
    if endtime-starttime>3*3:
        print "时间到，游戏结束"
        break
    roomnum=randint(1,10)
    print "当前{}号房间，请敲门或喂食（1表示敲门，2表示喂食）：".format(roomnum),
    chose=raw_input()
    if chose=="1":
        #调用敲门
        animaldict[roomnum].animalroar()
    elif chose=="2":
        while True:
            print "请选择需要喂得食物(meet或者gress):",
            food=raw_input()
            if food=="meet" or food=="gress":
                #调用喂食物
                animaldict[roomnum].eatfood(food)
                break
            else:
                print "输入错误"
                continue
    else:
        print "输入错误"
        continue
