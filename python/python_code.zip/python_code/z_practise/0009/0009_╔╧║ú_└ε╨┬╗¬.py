#coding=utf8
import time
import random
#定义一个老虎类
class Tigar:
    classname='Tiger'
    def __init__(self,weight=200):
        self.weight=weight
    def eat(self):
        self.weight += 10
    def cry(self):
        self.weight -= 5
        print 'Wow!!'
#定义一个羊类
class Sheet:
    classname='Sheet'
    def __init__(self,weight=100):
        self.weight=weight
    def eat(self):
        self.weight += 10
    def cry(self):
        self.weight -= 5
        print 'mie~~'
#定义一个房间类
class Room:
    def __init__(self,num,Animal):
        self.num=num
        self.Animal=Animal

if __name__=='__main__':
#开始计时
    t1=time.time()
#初始化房间，将10个房间放在一个字典中，每个房间随机分配老虎或者羊
    rooms={}
    for i in range(1,11):
        Animal=random.choice([Tigar(200),Sheet(100)])
        rooms[i]=Room(i,Animal)
#定义方法;喂食
    def wei(num,mima):
        if((mima=='meet' and rooms[num].Animal.classname=='Tiger') or (mima=='grass' and rooms[num].Animal.classname=='Sheet')):
            rooms[num].Animal.eat()
        else:
            rooms[num].Animal.weight-=10
#定义方法：敲门
    def qiaomen(num):
        rooms[num].Animal.cry()
#进入游戏，时间是三分钟
    while(time.time()<=t1+180):
#随机给出门牌号
        num=random.randint(1,10)
        print '房间门牌号是%d' %num
#让用户选择是否继续在该房间操作，如果继续则进行选择，如果推出仍重新给出新房间
        while(raw_input('是否继续选择')!='q'):
            try:
                optone=int(raw_input('''请选择下面的操作：
                输入1选择喂食；
                输入2选择敲门；\n'''))
                if optone==1:
                    opttwo=raw_input('''请输入单词：
                    喂老虎：meet
                    喂羊：grass\n''')
                    wei(num,opttwo)
                elif optone==2:
                    qiaomen(num)
                else:
                    print '重新输入你的选择'
            except ValueError:
                print '请输出正确的选择'
#打印每个房间的房间号，动物和体重
    for num in rooms:
        print num,rooms[num].Animal.classname,rooms[num].Animal.weight


    