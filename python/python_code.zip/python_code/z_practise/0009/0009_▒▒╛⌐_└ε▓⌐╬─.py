#coding:utf-8

from random import randint
import random
import time

class Animal(object):
    animal = random.choice(['tiger','sheep'])
    def __init__(self,animal):
        if self.animal == 'tiger':
            self.weight = 200
        elif self.animal == 'sheep':
            self.weight = 100


    def knock(self):
        voice = random.choice(['wow','mie'])
        if voice == 'wow':
            self.animal = 'tiger'
            self.weight = 200
            self.weight -= 5
            print 'wow'
            print 'the %s weight is %s and its roomnumber is %d'%(self.animal,self.weight,randint(1,11))
        else:
            self.animal = 'sheep'
            self.weight = 100
            self.weight -= 5
            print 'mie'
            print 'the %s weight is %s and its roomnumber is %d'%(self.animal,self.weight,randint(1,11))

    def feed(self):
        print 'please choose the food:meat or grass?'
        food = raw_input('>')
        if food == 'meat':
            print Animal.animal
            if Animal.animal == 'tiger':

                self.weight += 10
                print 'you are right!!'
                print 'the %s weight is %s and its roomnumber is %d'%(Animal.animal,self.weight,randint(0,11))
            else:
                self.weight -= 10
                print 'oh oh ,you got wrong'
                print 'the %s weight is %s and its roomnumber is %d'%(Animal.animal,self.weight,randint(0,11))
        elif food == 'grass':
            print Animal.animal
            if Animal.animal == 'sheep':
                self.weight += 10
                print 'you are right!!'
                print 'the %s weight is %s and its roomnumber is %d'%(Animal.animal,self.weight,randint(0,11))
            else:
                self.weight -= 10
                print 'oh oh ,you got wrong'
                print 'the %s weight is %s and its roomnumber is %d'%(Animal.animal,self.weight,randint(0,11))


def start():

    cur_time = time.time()
    print cur_time

    while True:
        animal = random.choice(['tiger','sheep'])
        s = Animal(animal)
        print 'please choose the way which is 1: knock, 2: feed to start your game'
        way = raw_input('>')
        if way == '1':
            s.knock()
        elif way =='2':
            s.feed()   #这块调用的时候，永远都是固定的一个动物，貌似没有实现random.choice(['tiger','sheep']的作用
        else:
            start()
        last_time = time.time()
        print '--------------------------------------------------\n'
        if last_time - cur_time > 180:
            print 'Game Over !!'
            break


start()




