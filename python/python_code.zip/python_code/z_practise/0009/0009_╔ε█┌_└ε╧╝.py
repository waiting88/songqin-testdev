# coding=utf8
from random import randint
import time
# 定义老虎类
class Tiger(object):
    classname = 'tiger'

    def __init__(self, weight=200):
        self.weight = weight

    def roar(self):
        print 'Wow!!'
        self.weight -= 5

    def feed(self, food):
        if food == 'meat':
            self.weight += 10
            print 'good , weight +10'
        else:
            self.weight -= 10
            print 'bad , weight -10'

# 定义羊类
class Sheep:
    classname = 'sheep'

    def __init__(self, weight=100):
        self.weight = weight

    def roar(self):
        print 'mie~~'
        self.weight -= 5

    def feed(self, food):
        if food == 'meat':
            self.weight -= 10
            print 'bad, weight -10'
        else:
            self.weight += 10
            print 'good , weight +10'

# 定义房间类
class Room:
    def __init__(self, num, animal):
        self.num = num
        self.animal = animal

#创建老虎类实例：
t1=Tiger()
t3=Tiger()
t4=Tiger()
t6=Tiger()
t9= Tiger()
#创建羊类实例
s2=Sheep()
s5=Sheep()
s7=Sheep()
s8=Sheep()
s10= Sheep()


#循环将羊实例或者老虎实例分别装入10个房间中：
load=[0,t1,s2,t3,t4,s5,t6,s7,s8,t9,s10]                                         #随机分配各个实例对象存入列表中
i = 0
while i < 10:
    num = randint(1, 10)
    if num in (1, 4, 6, 3, 9):
        room = Room(num, load[num])
    else:
        room = Room(num, load[num])
    i += 1

#制定游戏规则：
curTime1 = time.time()
endTime = curTime1 + 5
print curTime1
print endTime
curTime2=curTime1

while(curTime2 < endTime):                                                               #限制游戏时间
    curTime2 = time.time()
    print '************************************************************************************************************'
    print u'游戏开始！！'
    print u'游戏开始时间：%f' % curTime2
    roomNum = randint(1, 10)
    print '房间号是：%d' % roomNum
    curTime2 = time.time()

    choice = raw_input('请输入你的选择（敲门或者喂食）:')

    if choice == '敲门':                                                               #如果用户选择敲门
        if roomNum in (1, 3, 4, 6, 9):                                                #如果房间号里面装的是老虎
            print "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%动物状况为%%%%%%%%%"
            print u'房号：%d' % roomNum
            load[roomNum].roar()
            print '当前体重为：%d' % Room(roomNum,load[roomNum]).animal.weight

        else:                                                                         #如果房间号里面装的是羊
            print "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%动物状况为%%%%%%%%%"
            print u'房号：%d' % roomNum
            load[roomNum].roar()
            print '当前体重为：%d' % Room(roomNum,load[roomNum]).animal.weight

    else:                                                                   #如果用户选择喂食
        food = raw_input('请输入你要喂的食物（meat or grass）:')
        if roomNum in (1, 3, 4, 6, 9):                                               #如果房间号里面装的是老虎
            print "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%动物状况为%%%%%%%%%"
            print u'房号：%d' % roomNum
            Room(roomNum,load[roomNum]).animal.classname
            load[roomNum].feed(food)
            print '当前体重为：%d' % Room(roomNum,load[roomNum]).animal.weight
        else:                                                                         #如果房间号里面装的是羊
            print "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%动物状况为%%%%%%%%%"
            print u'房号：%d' % roomNum
            print Room(roomNum,load[roomNum]).animal.classname
            load[roomNum].feed(food)
            print '当前体重为：%d' % Room(roomNum,load[roomNum]).animal.weight
    curTime2 = time.time()



#循环打印十个房间里面的动物房号，动物类别，动物体重
print "#########################输出最后结果###############"
j = 1
roomnum= 1
m = range(0, 11)

while (j < 11):
    if m[roomnum] in (1, 3, 4, 6, 9):
        print Room(roomnum,load[roomnum]).num,Room(roomnum,load[roomnum]).animal.classname,Room(roomnum,load[roomnum]).animal.weight


    else:
        print Room(roomnum,load[roomnum]).num,Room(roomnum,load[roomnum]).animal.classname,Room(roomnum,load[roomnum]).animal.weight

    roomnum += 1
    j += 1
print '游戏开始时间为：%f' % curTime1
print '游戏结束时间为：%f' % time.time()