# coding:utf-8
import random
import time
import pprint
class Room:
    def __init__(self, nums, animal):
        self.nums = nums
        self.animal = animal
class Tiger:
    def __init__(self, weight=200, name='tiger'):
        self.weight = weight
        self.name = name
    def call(self):
        call_t = "wow!!"
        print call_t
        self.weight -= 5
    def food(self, input1):
        self.input1 = input1
        if self.input1 == "meet":
            self.weight += 10
            print "恭喜您喂对了，动物体重加10斤"
        else:
            self.weight -= 10
            print "您喂错了，动物体重减10斤"
class Sheep:
    def __init__(self, weight=100, name='sheep'):
        self.name = name
        self.weight = weight
    def call(self):
        call_s = "mie~~!!"
        self.weight -= 5
        print call_s
    def food(self, input):
        self.input = input
        if self.input == "grass":
            self.weight += 10
            print "恭喜您喂对了，动物体重加10斤"
        else:
            self.weight -= 10
            print "您喂错了，动物体重减10斤"
def game():
    startt = time.time()
    result = {}
    while True:
        t = Tiger()
        s = Sheep()
        num=random.randint(1,10)
        list = [t.name, s.name]
        animals = random.choice(list)
        r = Room(num, animals)
        print "房间号:%d"%r.nums
        ipt = raw_input("请选择喂食或是敲门：")
        if ipt == "喂食":
            ipt2 = raw_input("请选择食物meet或是grass：")
            if r.animal == "tiger":
                t.food(ipt2)
                result[r.nums] = [r.animal, t.weight]
            elif r.animal == "sheep":
                s.food(ipt2)
                result[r.nums] = [r.animal, s.weight]
        elif ipt == "敲门":
            if r.animal == "tiger":
                t.call()
                result[r.nums] = [r.animal, t.weight]
            elif r.animal == 'sheep':
                s.call()
                result[r.nums] = [r.animal, s.weight]
        endt = time.time()
        if endt > startt + 180:
            break
    return result
rlt=game()
pprint.pprint(rlt)

