#encoding=utf8
#要求大家用面向对象的设计编写一个python程序，实现一个文字游戏系统。
#动物园里面有10个房间，房间号从1 到 10。
#每个房间里面可能是体重200斤的老虎或者体重100斤的羊。
#游戏开始后，系统随机在10个房间中放入老虎或者羊。
#然后随机给出房间号，要求游戏者选择敲门还是喂食。
#如果选择喂食：
#喂老虎应该输入单词 meet，喂羊应该输入单词 grass
#喂对了，体重加10斤。 喂错了，体重减少10斤
#如果选择敲门：
#敲房间的门，里面的动物会叫，老虎叫会显示 ‘Wow !!’,羊叫会显示 ‘mie~~’。 动物每叫一次体重减5斤。
#游戏者强记每个房间的动物是什么，以便不需要敲门就可以喂正确的食物。
#游戏3分钟结束后，显示每个房间的动物和它们的体重。



class Animal:

    def __init__(self,weight):
        self.weight = weight

    def Roar(self,animal):
        self.weight -= 5
        if animal == 'tiger':
            print 'Wow !!'
        else:
            print 'mie~~'

    def Eat(self,animal,eatfood):
        if animal == 'tiger' and eatfood == 'meat':
            self.weight += 10
        elif animal == 'sheep' and eatfood == 'grass':
            self.weight += 10
        elif eatfood != 'meat' and eatfood != 'grass':
            print u'错误输入！'
        else:
            self.weight -= 10


from random import randint
import random

roomlist = []
for num in range(0,10):
    ani = random.choice(['tiger', 'sheep']) #每个房间里面随机放入动物
    if ani == 'tiger':
        roomlist.insert(num,[ani,200])
    else :
        roomlist.insert(num, [ani, 100])
#print roomlist

import sys


print '--------------THE GAME IS START!!-------------------'
import time
startTime = time.time()
nowTime = int(startTime)
#print startTime
while nowTime < startTime + 180:  #游戏时间3min
    roomnum = int(randint(0,9))
    print 'The RoomNumber Is %d'%(roomnum+1)
    animal = Animal(roomlist[roomnum][1])
    print u'请选择\"敲门\"还是\"喂食\"（knock or feed）:'
    action_one = raw_input()
#    try:
#        action_one = action_one.decode('utf8')
#    except UnicodeDecodeError:
#        action_one = action_one.decode('gbk')
    action_one = action_one.decode(sys.stdin.encoding).strip()
    if action_one == 'knock' or action_one == u'敲门':
        roar = animal.Roar(roomlist[roomnum][0])
        roomlist[roomnum][1] = animal.weight
#        print roomlist[roomnum][0],roomlist[roomnum][1]
    elif action_one == 'feed' or action_one == u'喂食':
        print u'选择喂食食物（meat or grass）：'
        action_two = raw_input()
        action_two = action_two.strip()
        eat = animal.Eat(roomlist[roomnum][0],action_two)
        roomlist[roomnum][1] = animal.weight
#        print roomlist[roomnum][0],roomlist[roomnum][1]
    else:
        print u'输入错误！'
    nowTime = int(time.time())
    print '\n----------------------------------------------\n'
#    print nowTime

print '---------------TIME   OUT------------------------'
print '----------------GAME OVER------------------------'
for number in range(0,10):
    print u'房间号：{:<2},动物：{:<6},体重：{:<4}'.format(number+1,roomlist[number][0],roomlist[number][1])







