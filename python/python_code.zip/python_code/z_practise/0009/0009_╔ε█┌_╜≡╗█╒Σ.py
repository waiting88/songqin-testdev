# coding=utf-8
import time
import random
import signal
from threading import Timer,Event

class Room:

    def __init__(self,num,animal):
        # type: (object, object) -> object
        self.num=num
        self.animal=animal
        if self.animal == 0:
            self.weigth=200
        else:
            self.weigth=100
    def opengate(self):
        if self.weigth > 5:
            self.weigth=self.weigth-5
            if self.animal ==0:
                print 'Wow!!'
            else:
                print 'mie~~'
        else:
            print "Animal die"

    def feedAnimal(self,animal):
        if self.animal == animal:
            self.weigth +=10
        else:
            self.animal -=10

    def showmsg(self):
        if self.animal ==0:
            print "ROOM: %d  Tiger  weigth: %d" % (self.num,self.weigth)
        else:
            print "ROOM: %d  Sheep weigth:   %d" % (self.num,self.weigth)


def userOp(room):
    # print __name__
    print "进入 Room %d" % room.num
    choice=raw_input("敲门输入0，喂食输入1：")
    if choice.strip() == '0':
        room.opengate()
    elif choice.strip() == '1':
        userfeed(room)
    else:
        print '选项输入有误，请重新输入!'

def userfeed(room):
    # print __name__
    choice =raw_input("喂老虎输入meet，喂羊输入grass：")
    if choice.strip() == 'meet':
        room.feedAnimal(0)
    elif choice.strip() == 'grass':
        room.feedAnimal(1)
    else:
        print '单词输入有误，请重新输入!'


# if __name__ == '__main__':
startTime=time.time()

# def handler1(signum, frame):
#     raise AssertionError
#signal.alarm(3)

AllAnimal=[]

i=10
while(i > 0):
    j=random.randint(0,1)
    room=Room(i,j)
    AllAnimal.append(Room(i,j))
    i =i-1
    # print len(AllAnimal)
    # i=5
    # endTime=time.time()

while (True):
    j=random.randint(0,9)
    userOp(AllAnimal[j])
    # try:
    #     # signal.signal(signal.SIGBREAK, handler1)
    #     # signal.signal(5)
    #     userOp(AllAnimal[j])
    #     # i=i-1
    #     endTime = time.time()
    #     #signal.signal(signal.SIGALRM, handler)
    #     # signal.alarm(0)
    # # except AssertionError:
    #     break
    endTime = time.time()

    if endTime - startTime >180:
        print 'Time up,Game over,Retry'
        break

for ii in AllAnimal:
     ii.showmsg()



















