#coding=utf-8
import datetime
from random import randint
'''
要求大家用面向对象的设计编写一个python程序，实现一个文字游戏系统。
动物园里面有10个房间，房间号从1 到 10。
每个房间里面可能是体重200斤的老虎或者体重100斤的羊。
游戏开始后，系统随机在10个房间中放入老虎或者羊。
然后随机给出房间号，要求游戏者选择敲门还是喂食。
如果选择喂食：
喂老虎应该输入单词 meet，喂羊应该输入单词 grass
喂对了，体重加10斤。 喂错了，体重减少10斤
如果选择敲门：
敲房间的门，里面的动物会叫，老虎叫会显示 ‘Wow !!’,羊叫会显示 ‘mie~~’。 动物每叫一次体重减5斤。
游戏者强记每个房间的动物是什么，以便不需要敲门就可以喂正确的食物。
游戏3分钟结束后，显示每个房间的动物和它们的体重。
'''
Curtime = datetime.datetime.now()
print '初始时间为：',Curtime
Scrtime = Curtime + datetime.timedelta(0,180,0)
print '目标时间为:',Scrtime
class Room():
    def __init__(self,num,animal):
        self.num=num
        self.animal=animal
class Tiger():
    classname='tiger'
    def __init__(self,weight=200):
        self.weight=weight
    def roar(self):
        self.weight -=5
        print 'Wow !!'
    def feed1(self,food):
        if self.food=='meet':
            self.weight +=10
        else:
            self.weight -= 10
class Sheep():
    classname='sheep'
    def __init__(self,weight=100):
        self.weight=weight
    def roar(self):
        self.weight -= 5
        print 'mie~~'

    def feed1(self, food):
        if self.food=='grass':
            self.weight += 10
        else:
            self.weight  -= 10
room_numbe=[]
for i in xrange(0,10):
    room_numbe.append(randint(0,1))
    if room_numbe[i]==0:
        room_numbe[i]='tiger'
    else:
        room_numbe[i]='sheep'
print room_numbe
 #游戏开始
while  datetime.datetime.now()<=  Scrtime :
    #随机给出房间号
    j=randint(1,10)
    animal=room_numbe[j-1]
    if animal=='tiger':
        A1=Tiger()
    else:
        A1=Sheep()
    print A1.weight
    Room1=Room(j,A1)
    print Room1.num
    #要求游戏者选择敲门还是喂食，0代表敲门，1代表喂食
    Choice=int(raw_input('请选择敲门还是喂食:0代表敲门，1代表喂食'))
    if  Choice == 0:
        A1.roar()
    else :
        Feed=int(raw_input('请选择喂食meet或者grass:0代表meet，1代表glass'))
        if Feed<1:
            A1.food='meet'
        else:
            A1.food='grass'
        A1.feed1(A1.food)
    print A1.weight







