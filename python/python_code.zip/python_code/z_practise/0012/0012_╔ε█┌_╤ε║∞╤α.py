#coding=utf-8
''' ***** 编程题 0012 ******
下载附件中的excel表格
中国电话区号.xls
该表格里面记录了中国各市的电话区号，但所有的信息都在一个表单中，如下所示
请编写Python程序，根据这个excel文件创建另一个excel文件，要求 每个省或直辖市独占一个表单，里面记录本省、直辖市的电话区号。'''

import xlrd
#import xlwt
from xlwt import *

try:
    book=xlrd.open_workbook("./中国电话区号.xls".decode("utf-8"))#打开一个excl
    # print book.nsheets
except Exception ,e:
    print "文件错误"
else:
    sh = book.sheets()[0]#获取sheet的
    sname=sh.name#sheet名字
    nrows = sh.nrows #行数
    ncols = sh.ncols #列数
    # print ("{0} {1} {2}").format(sname, nrows, ncols)  # sheet名称和行数列数
    #创建工作簿
    w = Workbook()
    tempRow = 0
    tempWs = ''
    for col in range(0, ncols, 2):#循环列，以每两列循环一次
        for row in range(0, nrows):#读取每一行
            cityName = sh.cell_value(rowx=row, colx=col)#得到城市名称
            cityCode = sh.cell_value(rowx=row, colx=col+1)#得到城市代码
            print cityName,cityCode
            if row == 0:#直辖市
                tempWs = w.add_sheet(cityName)
                tempRow = 0
            else:
                if (cityName == '' and cityCode == ''):#城市和城市代码同时为空，则跳过循环
                    continue
                elif (cityName != '' and cityCode == ''):#城市不为空，城市代码为空，则为省份，需要创建表
                    tempWs = w.add_sheet(cityName)
                    tempRow = 0
            tempWs.write(tempRow, 0, cityName)
            tempWs.write(tempRow, 1, cityCode)
            tempRow+=1
    w.save('./cityTemp.xls')



