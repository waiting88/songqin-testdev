# coding=utf-8
import xlrd
import xlwt

data = xlrd.open_workbook(u'中国电话区号.xls')
workBook = xlwt.Workbook(encoding='utf8')
table = data.sheets()[0]
# 直辖市
for coln1 in range(0, table.ncols, 2):
    cell1 = table.cell_value(0, coln1)
    cell2 = table.cell_value(0, coln1 + 1)
    worksheet = workBook.add_sheet(cell1)
    worksheet.write(0, 0, cell1)
    worksheet.write(0, 1, cell2)
for coln2 in range(0, table.ncols, 2):
    for rown2 in range(1, table.nrows):
        cellx = table.cell_value(rown2, coln2)
        celly = table.cell_value(rown2, coln2 + 1)
        if cellx:
            if not celly:
                i = 0
                sheetName = cellx
                worksheet = workBook.add_sheet(sheetName, cell_overwrite_ok=True)
            x = worksheet.write(i, 0, cellx)
            y = worksheet.write(i, 1, celly)
            i += 1
workBook.save('D:\\pythontLearn\\phone1.xls')