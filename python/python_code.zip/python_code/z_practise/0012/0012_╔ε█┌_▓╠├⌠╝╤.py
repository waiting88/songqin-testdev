__author__ = 'caimj'
#coding=utf-8
import xlrd,sys
import xlwt
try:
    data = xlrd.open_workbook(u'中国电话区号.xls')

except Exception,e:
    print str(e)
table = data.sheets()[0]
nrows = table.nrows #行数
ncols = table.ncols #列数
worksheet1= data.sheet_by_name(u'Sheet1')
workBook = xlwt.Workbook(encoding='utf-8')
for coln in range(0,ncols,2):
    for rown in range(1,nrows):
        cell1 = table.cell_value(rown,coln)
        cell2 = table.cell_value(rown,coln+1)
        print cell1,cell2
        #sheet对象
        if cell1!='':
            if  not cell2:
                i=0
                sheetname=cell1
                worksheet= workBook.add_sheet(sheetname,cell_overwrite_ok=True)
            worksheet.write(i,0,cell1)
            worksheet.write(i,1,cell2)
            i+=1

workBook.save(u'中国电话区号2.xls')