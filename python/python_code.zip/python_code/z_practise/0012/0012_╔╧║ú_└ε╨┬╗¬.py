#coding=utf8
import xlrd,xlwt
#打开‘中国电话区号’excel表格，将数据存储到一个列表alist中
f1=xlrd.open_workbook(u'C:\\Python27\\test\\中国电话区号.xls')
sheet1=f1.sheet_by_index(0)
rows=sheet1.nrows
cols=sheet1.ncols
alist=[]
for j in range(0,cols,2):
    for i in range(0,rows):
        name= sheet1.row(i)[j].value.encode('utf-8')
        value= sheet1.row(i)[j+1].value.encode('utf-8')
        alist.append(name+':'+value)
        
#新建一个excel，将列表alist中的数值写入表格中，判断列表分割后的数值中是否有空值，有空值时新建一页，将数据存在在该sheet中
workbook=xlwt.Workbook(encoding='utf-8')
worksheet=workbook.add_sheet(alist[0].split(':')[0])
for i in range(len(alist)):
    name=alist[i].split(':')[0]
    value=alist[i].split(':')[1]
    if name:
        if not value:
            worksheet=workbook.add_sheet(name)
    worksheet.write(i,0,name)
    worksheet.write(i,1,value)
workbook.save('c:/python27/test/demo1.xls')

#新建一个表格，将有值得单元格的数据保存到列表blist中，在将blist中的数据写入到新的单元格中
work1=xlrd.open_workbook('c:/python27/test/demo1.xls')
work2=xlwt.Workbook(encoding='utf-8')
for sheet in work1.sheets():
    wsheet=work2.add_sheet(sheet.name)
    blist=[]
    for i in range(sheet.nrows):
           if sheet.cell(i,0).value:
               blist.append(sheet.row(i)[0].value+':'+sheet.row(i)[1].value)
    print blist
    for i in range(len(blist)):
        wsheet.write(i,0,blist[i].split(':')[0])
        wsheet.write(i,1,blist[i].split(':')[1])
work2.save('c:/python27/test/demo2.xls')

