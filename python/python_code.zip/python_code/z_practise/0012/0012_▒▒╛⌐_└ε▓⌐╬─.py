#coding:utf-8

import xlrd,xlwt

data = xlrd.open_workbook(u'中国电话区号.xls')
w = xlwt.Workbook(encoding='utf-8')

table = data.sheet_by_index(0)
#先搞定直辖市
for name_cnum in range(0,12,2):
    #先获取直辖市的名字和区号
    zname = table.row_values(0)[name_cnum]
    zcode = table.col_values(name_cnum+1)[0]
    #print zname,zcode
    ws = w.add_sheet(zname)
    ws.write(0,0,zname)
    ws.write(0,1,zcode)

#省市开始
rows = table.nrows
for name_cnum in range(0,12,2):

    for row in range(1,rows):
        sname = table.cell_value(row,name_cnum)
        scode = table.cell_value(row,name_cnum+1)
        #判断表头是否是省名
        if sname:
            if not scode:
                i = 0
                province = sname
                ws = w.add_sheet(province,cell_overwrite_ok=True)

            ws.write(i,0,sname)
            ws.write(i,1,scode)
        i +=1

w.save('China_zipcode.xls')
