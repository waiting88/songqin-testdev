#coding=utf8
#经验教训1；自我感觉对着 但报错 实在看不出哪错时 不要瞎浪费时间 一定要debug，debug debug！！！！！！
import xlrd,xlwt
book=xlrd.open_workbook(u'中国电话区号.xls')
sh=book.sheet_by_index(0)
zhixiashiNamelist=[]
zhixiashiCodeList=[]
colidx1=0      #城市名字所在的列
colidx2=1       #区号所在的列
#将直辖市名字和直辖市区号分别存入列表zhixiashiNamelist和zhixiashiCodeList
while colidx1 < sh.ncols and colidx2 < sh.ncols:
     zhixiashiName= sh.cell_value(0,colidx1)
     zhixiashiNamelist.append(zhixiashiName)
     zhixiashiCode=sh.cell_value(0,colidx2)
     zhixiashiCodeList.append(zhixiashiCode)
     colidx1+=2
     colidx2+=2

#将zhixiashiNamelist和zhixiashiCodeList中的值写入各自对应的sheet表中
workbook=xlwt.Workbook()
i=0
#遍历直辖市列表，创建直辖市命名的sheet
for one in zhixiashiNamelist:
       sheet = workbook.add_sheet(one)
       sheet.write(0,0,zhixiashiCodeList[i])
       i+=1
#创建省列表
provicelist=[]
rows=[1,16,28,53]
j=0
while j < len(rows):
    colidx1=0
    while colidx1 < sh.ncols:
        proviceName=sh.cell_value(rows[j],colidx1)
        # print proviceName
        provicelist.append(proviceName)
        colidx1 += 2
    j+=1
provicelist.append(sh.cell_value(64,0))

#定义获取原excel表中的城市和区号，并将城市存入citylist列表，将区号存入codelist列表的函数，以便后续调用
def getCityAndCode(x,y,colidxName,colidxCode):
    #x,y为一个省所占据的行的范围，colidxName为城市所在的列,colidxCode为区号所在的列
    citylist = []
    codelist = []
    for row in range(x,y):
            if sh.cell_value(row,colidxName):
                cityName=sh.cell_value(row,colidxName)
                citylist.append(cityName)
                citycode=sh.cell_value(row,colidxCode)
                codelist.append(citycode)
    return citylist, codelist

#定义将城市和区号写入以省命名的sheet表的函数，以便后续调用
def writeCityAndCodeTo(pro,x,y,colidxName,colidxCode):
   #pro为遍历provice列表的索引 x, y为一个省所占据的行的范围，colidxName为城市所在的列, colidxCode为区号所在的列
        citylist, codelist = getCityAndCode(x,y,colidxName,colidxCode)
        idx = i = j =0
        sheet1 = workbook.add_sheet(provicelist[pro])
        while i<len(citylist) and j<len(codelist) and idx<len(codelist):
                sheet1.write(idx,1,citylist[i])
                sheet1.write(idx,2,codelist[j])
                i+=1
                j+=1
                idx+=1

#创建以省命名的sheet并将城市和区号写入对应的sheet表中
for one1 in provicelist:
    #provice列表的前0-5组,行数为2-16，列数依次为0-1,2-3,4-5,6-7,8-9,10-11:
    if one1 == provicelist[0]:
        writeCityAndCodeTo(0,2,16,0,1)
    if one1 ==provicelist[1]:
        writeCityAndCodeTo(1, 2, 16, 2, 3)
    if one1 == provicelist[2]:
        writeCityAndCodeTo(2,2,16,4,5)
    if one1 ==provicelist[3]:
        writeCityAndCodeTo(3, 2, 16, 6, 7)
    if one1 == provicelist[4]:
        writeCityAndCodeTo(4,2,16,8,9)
    if one1 ==provicelist[5]:
        writeCityAndCodeTo(5, 2, 16, 10, 11)
    #provice列表的6-11组,行数为17-28，列数依次为0-1,2-3,4-5,6-7,8-9,10-11:
    if one1 == provicelist[6]:
        writeCityAndCodeTo(6,17,28,0,1)
    if one1 ==provicelist[7]:
        writeCityAndCodeTo(7, 17,28, 2,3)
    if one1 == provicelist[8]:
        writeCityAndCodeTo(8,17,28,4,5)
    if one1 ==provicelist[9]:
        writeCityAndCodeTo(9, 17,28,6,7)
    if one1 == provicelist[10]:
        writeCityAndCodeTo(10,17,28,8,9)
    if one1 ==provicelist[11]:
        writeCityAndCodeTo(11, 17,28,10,11)
    # provice列表的12-17组,行数为29-53，列数依次为0-1,2-3,4-5,6-7,8-9,10-11:
    if one1 == provicelist[12]:
        writeCityAndCodeTo(12,29,53,0,1)
    if one1 ==provicelist[13]:
        writeCityAndCodeTo(13, 29,53, 2,3)
    if one1 == provicelist[14]:
        writeCityAndCodeTo(14,29,53,4,5)
    if one1 ==provicelist[15]:
        writeCityAndCodeTo(15, 29,53, 6,7)
    if one1 == provicelist[16]:
        writeCityAndCodeTo(16,29,53,8,9)
    if one1 ==provicelist[17]:
        writeCityAndCodeTo(17, 29,53,10,11)
    # provice列表的18-23组,行数为29-53，列数依次为0-1,2-3,4-5,6-7,8-9,10-11:
    if one1 == provicelist[18]:
        writeCityAndCodeTo(18,29,53,0,1)
    if one1 ==provicelist[19]:
        writeCityAndCodeTo(19, 29,53,2,3)
    if one1 == provicelist[20]:
        writeCityAndCodeTo(20,29,53,4,5)
    if one1 ==provicelist[21]:
        writeCityAndCodeTo(21,29,53,6,7)
    if one1 == provicelist[22]:
        writeCityAndCodeTo(22,29,53,8,9)
    if one1 ==provicelist[23]:
        writeCityAndCodeTo(23, 29,53,10,11)
    #provice列表的最后一组23，行数为65-67,列数为0-1
    if one1 == provicelist[24]:
        writeCityAndCodeTo(24,65,67, 0, 1)
workbook.save('result9.xls')
print 'ok'