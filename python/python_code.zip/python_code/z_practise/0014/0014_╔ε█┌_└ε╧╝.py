#coding=utf8
from socket import *
import sys
HOST = 'localhost'
PORT = 21567
BUFSIZE = 1024
ADDR = (HOST,PORT)

class CloseSocketError:
    pass

#一个Connection处理和一个服务端的通信
class ConnectionHandler:
    #0008|1|nicknam
    LEN_MSG_LEN_FILED = 4
    LEN_MSG_LEN_TYPE_FILED = 7

    def __init__(self,sock):
        #消息缓存区
        self._readbuffer = ""
        self.sock = sock
        self.customername= ''
    #msgbody是unicode
    @staticmethod
    def encode(msgType,msgBody):
        rawMsgBody = msgBody.encode('utf8')
        return '%04d|%s|%s' % (len(rawMsgBody)+ConnectionHandler.LEN_MSG_LEN_TYPE_FILED,
                               msgType,
                               rawMsgBody)
    @staticmethod
    def decode(rawmsg):
        msgType = int(rawmsg[5])
        msgbody = rawmsg[ConnectionHandler.LEN_MSG_LEN_TYPE_FILED:].decode('utf8')
        return [msgType,msgbody]
    def readMsg(self):
        bytes = self.sock.recv(BUFSIZE)

        #当服务器关闭时 跑出异常
        if not bytes:
            self.sock.close()
            raise CloseSocketError()

        self._readbuffer += bytes
        buffLen = len(self._readbuffer)
        #如果已经获取了消息头部（包括消息长度，消息类型）
        if buffLen >= self.LEN_MSG_LEN_TYPE_FILED:
            msgLen = int(self._readbuffer[:self.LEN_MSG_LEN_FILED])
            if buffLen >= msgLen:
                #从缓存区截取整个消息
                msg = self._readbuffer[0:msgLen]
                #缓存区变成剩余的消息部分
                self._readbuffer = self._readbuffer[msgLen:]
                return  self.decode(msg)
        #如果已经获取的消息还不包括一个完整的消息头部，不做处理，等待下面继续接收消息
        else:
            return None
        print 'get:%s' % bytes
    #msgBody 是Unicode
    def sendMsg(self,msgType,msgBody):
        self.sock.sendall(self.encode(msgType,msgBody))
    def handleMsg(self,msgType,msgBody):
        #客户名称
        if msgType == 1:
            self.customername = msgBody
            print u'客户名称设置：%s' % self.customername
        #普通消息
        elif msgType == 2:
            print msgBody
            print '------------------------'

    #主循环，不断的发送消息
    def mainloop(self):
        while True:
            data0 = raw_input(u'请输入你想说的话:')  # 客户端发消息给服务端
            udata0 = data0.decode(sys.stdin.encoding)
            if not data0:
                break
            self.sendMsg(2, udata0)

            try:                         #客户端接收服务器回复的消息
                data1 = self.readMsg()
                if  data1:
                    msgType, msgBody = data1
                    self.handleMsg(msgType, msgBody)
            except CloseSocketError:
                print u'对方断开了连接,等待下一个客户'
                break
            except IOError:
                print u'对方断开了连接,等待下一个客户'
                break

        tcpCliSock.close()

tcpCliSock = socket(AF_INET,SOCK_STREAM)   #创建socket ,指明协议
while True:
    tcpCliSock.connect(ADDR)  # 连接远程地址和端口，发送syn, 等待syn,ack
    handler = ConnectionHandler(tcpCliSock)
    data = raw_input(u'请输入你的昵称:')  # 客户端第一次消息给服务端，告诉服务端自己的昵称，只执行一次
    udata = data.decode(sys.stdin.encoding)
    if not data:
        break
    handler.sendMsg(1, udata)
    handler.mainloop()



