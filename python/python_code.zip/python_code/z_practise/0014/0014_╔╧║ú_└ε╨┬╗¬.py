#coding=utf8
from socket import *
HOST='localhost'
PORT=21567
ADDR=(HOST,PORT)
MSG_HEAD_LEN=7
tcpclisk=socket(AF_INET,SOCK_STREAM)
tcpclisk.connect(ADDR)
class CloseSocketError(Exception):
    pass
def sendMsg(type,data):
    data = data.encode('utf-8')
    msg_len=MSG_HEAD_LEN+len(data)
    msg='{:>4}|{}|{}'.format(msg_len,type,data)
    tcpclisk.send(msg)
def recvMsg():
    data=tcpclisk.recv(1024)
    if not data:
        tcpclisk.close()
    print data

name=raw_input('enter your name:')
sendMsg(1,name)
while True:
    try:
        data=raw_input('>>')
        if data:
            sendMsg(2,data)
            recvMsg()
    except CloseSocketError:
        break
tcpclisk.close()






