#coding=utf8
#命名三个文件的文件路径
path1="c:/python27/0008/teacher.txt"
path2="c:/python27/0008/course.txt"
path3="c:/python27/0008/teacher_course.txt"
#构造函数，打开文件，将文件中每行值保存到列表
def openfile(filepath):
    alist=[]
    with open(filepath) as f:
        for one in f.readlines( ):
            alist.append(one.strip('\n').split(';'))
    return alist
#调用openfile函数，list1存放teacher.txt文件的信息，list2存放course.txt文件的信息，list3存放teacher_course.txt的文件信息
list1=openfile(path1)
list2=openfile(path2)
list3=openfile(path3)
#将需要的信息teacherid，teachername，courseid，coursename存放在两个字典中，id为键，名称为值
dict1={}
dict2={}
for i in range(1,len(list1)):
    dict1[list1[i][0]]=list1[i][4].decode('utf-8')
for i in range(1,len(list2)):
    dict2[list2[i][0]]=list2[i][1].decode('utf-8')
'''要求大家编写一个python程序，根据这3张表的内容，输出一个包含老师授课信息的文件。
要求格式为
老师姓名: 课程名，例如
小猪老师:  软件测试框架课程
mandy老师:  软件测试框架课程
mandy老师:  web测试技术课程
'''
#新建一个文件，将老师名称，对应的课程名称存放在新文件中，字符编码格式是'utf-8'
with open('c:/python27/0008/teachercourse.txt','a') as f:
    f.write('老师姓名：课程名\n')
    for teacherid,courseid in list3[1:]:
        f.write(dict1[teacherid].encode('utf-8')+':'+dict2[courseid].encode('utf-8')+'\n')



