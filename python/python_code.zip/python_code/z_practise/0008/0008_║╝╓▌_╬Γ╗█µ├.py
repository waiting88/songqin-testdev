# coding=utf-8
with open(u'teacher.txt', 'r') as f:
    teacher = f.read().split('\n')
    del teacher[0]
    del teacher[-1]
with open(u'course.txt', 'r') as f1:
    course = f1.read().split('\n')
    del course[0]
    del course[-1]
with open(u'teacher_course.txt', 'r') as f2:
    teacher_course = f2.read().split('\n')
    del teacher_course[0]
    del teacher_course[-1]
list = []
for i in teacher_course:
    teacher_id = i.split(';')[0]
    m = i.split(';')
    for j in teacher:
        id = j.split(';')[0]
        realname = j.split(';')[-1]
        if id == teacher_id:
            m.append(realname)
            list.append(m)
list1 = []
for k in list:
    id1 = k[1]
    for z in course:
        id = z.split(';')[0]
        name = z.split(';')[1]
        if id == id1:
            k.append(name)
            list1.append(k)
for y in range(len(list1)):
    del list1[y][0:2]
print ('��ʦ����  ���γ���')
for x in list1:
    teachername = x[0]
    classname = x[1]
    print '%s:%s' % (teachername, classname)