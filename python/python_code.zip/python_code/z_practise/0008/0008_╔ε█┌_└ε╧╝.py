#coding=utf8
#定义文件路径：
coursePath='H:/PYTHON/0008/course.txt'
teacherPath='H:/PYTHON/0008/teacher.txt'
teacher_coursePath='H:/PYTHON/0008/teacher_course.txt'

lengthCourse=len('id;name;desc;display_idx')
lengthteacher=len('id;user_id;desc;display_idx;realname')
lengthCourseTeacher=len('teacher_id;course_id')

#打开文件读取文件内容：
with open (coursePath) as f1:
    f1.seek(lengthCourse + 2)
    courseContent=f1.read().decode('utf8')

with open (teacherPath) as f2:
    f2.seek(lengthteacher + 2)
    teacherContent=f2.read().decode('utf8')

with open (teacher_coursePath) as f3:
    f3.seek(lengthCourseTeacher + 2)
    teacher_courseContent=f3.readlines()

#将course.txt文件中的内容读取，并将课程id和课程名字分别存入courseidlist，coursenamelist列表中
courselist = courseContent.splitlines()
courseidlist=[]
coursenamelist=[]
for course in courselist:
    courseidlist.append(course.split(';')[0])
    coursenamelist.append(course.split(';')[1])

#将teacher.txt文件中的内容读取并将老师id和老师名字分别存入teacheridlist，teachernamelist列表中
teacherlist=teacherContent.splitlines()
teacheridlist=[]
teachernamelist=[]
for teacher in teacherlist:
    teacheridlist.append(teacher.split(';')[0])
    teachernamelist.append(teacher.split(';')[4])

# 将teacher_course文件中的内容映射为字典,老师id为key,课程id为value，并且同一个老师所教的课程放在一个列表中作为value
teacherid2courseid={}
for tc in teacher_courseContent:
    teacherid,courseid = tc.replace('\n','').split(';')

    if teacherid in teacherid2courseid:
        teacherid2courseid[teacherid].append(courseid)
    else:
        teacherid2courseid[teacherid]=[courseid]

#计算出老师id列表与课程id列表中的元素个数，作为循环条件
Lenteacheridlist=len(teacheridlist)
Lencourseidlist=len(courseidlist)

f4=open('H:/PYTHON/0008/tname2cname.txt','w')

#分别遍历teacheridlist，courseidlist来一一对应到上述的字典中来进行tname2cname的匹配
for teacherid,courseid in teacherid2courseid.items():
    tidlist=[]
    tidlist.append(teacherid)
    lencourseid=len(courseid)
    i=j=0
    while (i<Lenteacheridlist):
        if teacheridlist[i] in tidlist:

            while (j < lencourseid):
                if courseidlist[j] in str(courseid):
                    print teachernamelist[i]+':'+coursenamelist[j]
                    f4.write(teachernamelist[i].encode('utf8')+ '  '+':'+'  '+coursenamelist[j].encode('utf8')+'\n')
                j += 1
        i+=1
f4.close()








