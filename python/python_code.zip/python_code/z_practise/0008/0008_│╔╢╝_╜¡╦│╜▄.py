#coding=utf-8

with open('teacher.txt') as f:
    dog = f.read()
    cat = dog.decode('utf8')
    teacherlist = cat.split('\n')
teacherzidian={}
for one in teacherlist:
    i = one.split(';')
    teacherid = i[0]
    teachername = i[-1]
    teacherzidian[teacherid] = teachername
with open('course.txt') as h:
    pig = h.read()
    monkey = pig.decode('utf8')
    courselist = monkey.split('\n')
coursezidian={}
for one in courselist:
    p = one.split(';')
    courseid = p[0]
    coursename = p[1]
    coursezidian[courseid] = coursename

with open('teacher_course.txt') as k:
    teacher_courselist = k.readlines()
with open('summarylist.txt', 'w')as o:
    for one in teacher_courselist:
        teacher_id = one.split(';')[0]
        course_id = one.split(';')[1]
        teachers = teacherzidian[teacher_id]
        courses = coursezidian[course_id]
        summary = '{}:{}'.format(teachers,courses)
        print summary
        o.write(summary.encode('utf8')+'\n')
