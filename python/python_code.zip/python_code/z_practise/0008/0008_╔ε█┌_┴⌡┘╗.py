#coding=utf-8
with open('0008\\teacher.txt') as f1:
    teachersInfoStr = f1.read()
    teachersInfoUC = teachersInfoStr.decode('utf')
    teachersList =teachersInfoUC.strip().split('\n')
teacherDict={}
for i in range(1, len(teachersList)):
    teacherId = teachersList[i].split(';')[0]     #得到了老师的id
    real_name = teachersList[i].split(';')[-1]        #得到了老师的realname
    teacherDict[teacherId] = real_name                 #生成一个字典，key:teacherId,value:real_name


with open('0008\\course.txt') as f2:
    courseInfoStr = f2.read()
    courseInfoUC = courseInfoStr.decode('utf')
    courseList = courseInfoUC.strip().split('\n')
courseDict = {}
for j in range(1,len(courseList)):
    courseId = courseList[j].split(';')[0]         #得到了课程的id
    course_name = courseList[j].split(';')[1]   #得到了课程的名称
    courseDict[courseId]=course_name            #生成一个字典，key:courseId,value:course_name


with open('0008\\teacher_course.txt') as f3:
    teacher_course_List = f3.readlines()        #将teacher_course.txt文件中的每一行读出


with open('teachername_coursename.txt','w') as f4:
    for a in range(1, len(teacher_course_List)):
        idList = teacher_course_List[a].strip().split(';')
        teacher_id = idList[0]
        course_id = idList[1]
        teachername = teacherDict.get(teacher_id)
        coursename = courseDict[course_id]
        teachername_coursename = '%s:%s' % (teachername, coursename)+'\n'
        f4.write(teachername_coursename.encode('utf-8'))









