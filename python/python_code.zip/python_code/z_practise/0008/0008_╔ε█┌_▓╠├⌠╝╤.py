__author__ = 'caimj'
#coding=utf-8
import pprint
def getFileContent(filename):
    with open(filename,'r') as f:
        content=f.readlines()
        content=[x.strip('\n') for x in content]
        content=[x.split(';') for x in content]
        return content
teacher_content =getFileContent('teacher.txt')
teacher_name=[]
teacher_id=[]
for i in teacher_content:
    teacher_id.append(i[0])
    teacher_name.append(i[-1])
teacher_dict=dict(zip(teacher_id,teacher_name))
teacher_dict.pop('id')
course_content =getFileContent('course.txt')
course_id=[]
course_name=[]
for i in course_content:
    course_id.append(i[0])
    course_name.append(i[1])
course_dict=dict(zip(course_id,course_name))
course_dict.pop('id')
teacher_course=getFileContent('teacher_course.txt ')
with open("teacher_course_new.txt",'w') as f2:
    teacher_course_list = []
    for i in teacher_dict:
        for j in course_dict:
            teacher_course_list.append("%-9s:%9s\n" % (teacher_dict[i],course_dict[j]))
    f2.writelines(teacher_course_list)










