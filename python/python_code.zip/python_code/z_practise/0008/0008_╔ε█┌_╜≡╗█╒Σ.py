#coding:utf-8
import os

def parseCourse(filename):
	lines=open(filename).readlines()
	dictA={}
	for line in lines:
		line=line.strip('\n')    #这里改成：line=line.strip() 也是ok的
		data=line.split(';')

		#以下判断data[0]取第一个行元素 或 data取到文件最后一行空行内容时，结束本次循环
		# if data[0] == 'id' or len(data) < 2:
		# 	print "Skip useless line"
		# 	continue
		dictA[data[0]]=data[1]
	# print dictA
	return dictA

def parseTeacher(filename):
	line=open(filename).readline()
	lines=open(filename).readlines()
	dictA={}
	for line in lines:
		line=line.strip('\n')   #这里改成：line=line.strip() 也是ok的
		data=line.split(';')
		# if data[0] == 'id' or len(data) < 2:
		# 	print "Skip useless line"
		# 	continue
		dictA[data[0]]=data[-1]
	# print dictA
	return dictA

#以下def parseTC(filename): 定义，2种方式都可以

# def parseTC(filename):
# 	with open(filename) as f:
# 		line = f.readline()     #先读出第一行
# 		dictA={}
# 		for line in f.readlines():
# 			line=line.strip('\n')   #这里改成：line=line.strip() 也是ok的
# 			print line
# 			data=line.split(';')
# 			# if data[0] == 'teacher_id'or len(data) < 2:
# 			# 	print "Skip useless line"
# 			# 	continue
# 			if dictA.has_key(data[0]):
# 				dictA[data[0]].append(data[-1])
# 			else:
# 				dictA[data[0]]=[data[-1]]
# 		print dictA
# 		return dictA

def parseTC(filename):
	lines=open(filename).readlines()
	dictA={}
	for line in lines:
		line=line.strip()
		data=line.split(';')
		# if data[0] == 'teacher_id'or len(data) < 2:
		if data[0] == 'teacher_id':
			print "Skip useless line"
			continue
		if dictA.has_key(data[0]):
			dictA[data[0]].append(data[-1])
		else:
			dictA[data[0]]=[data[-1]]
	# print dictA
	return dictA

dictC=parseCourse('008\course.txt')
dictT=parseTeacher(r'008\teacher.txt')
dictTC=parseTC(r'008\teacher_course.txt')

for (k,v) in dictTC.items():    #k,v分别是dictTC里的键-值对
	for vv in v:                #遍历课程id
		print "%s :%s" % (dictT[k],dictC[vv])
