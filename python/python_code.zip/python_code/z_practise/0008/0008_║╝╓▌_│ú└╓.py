#coding:utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
#分别打开3个文件，并读取里面的内容
with open("c:\\course.txt","r") as course:
    fl_course=course.readlines()
with open("c:\\teacher.txt","r") as teacher:
    fl_teacher=teacher.readlines()
with open("c:\\teacher_course.txt","r") as teacher_c:
    teacher_c=teacher_c.readlines()
#此函数用于获取课程id与课程名称
def courses():
    dict_course={}
    for line in fl_course:
        line=line.strip()
        course_id=line.split(";")[0]
        course_value=line.split(";")[1].decode("utf8")
        if course_id.isalpha():
            continue
        course_id = int(course_id)
        dict_course[course_id]=course_value
    return dict_course
#此函数用于获取老师id与老师的名字
def teachers():
    dict_teacher={}
    for line in fl_teacher:
        line=line.strip()
        id=line.split(";")[0]
        realname=line.split(";")[4].decode("utf8")
        if id.isalpha():
            continue
        id = int(id)
        dict_teacher[id]=realname
    return dict_teacher
#将上面两个函数的返回值分别赋给两个变量
result1=courses()
result2=teachers()
#此函数用于将老师的名字与对应的课程名称写入到新的文件中
def teachers_c(result1,result2):
    with open("c:\\result.txt", 'w') as result:
        for line in teacher_c:
            line=line.strip()
            t_id,c_id=line.split(";")
            is_num=t_id.isdigit()
            if is_num==False:
                continue
            t_id=int(t_id)
            c_id=int(c_id)
            tid_value=result2[t_id]
            cid_value=result1[c_id]
            rlt=tid_value+':'+cid_value
            result.write(rlt+"\n\n")
teachers_c(result1,result2)



