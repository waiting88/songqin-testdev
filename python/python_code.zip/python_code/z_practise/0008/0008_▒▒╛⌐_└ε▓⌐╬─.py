#coding=utf-8

# import json
with open ('C:\Users\New\Desktop\\0008\\teacher.txt') as t:
    lines1 = t.read().decode('utf8')
    tlines = lines1.splitlines()
    tlines.pop(0)
    teacherinfo = {}
    for tline in tlines:
         tlineelement = tline.split(';')
         tid = tlineelement[0]
         tname = tlineelement[4]
         teacherinfo[tid] = tname
    # print json.dumps(teacherinfo, encoding="UTF-8", ensure_ascii=False)

with open('C:\Users\New\Desktop\\0008\\course.txt') as c:
    lines2 = c.read().decode('utf8')
    clines = lines2.splitlines()
    clines.pop(0)
    courseinfor = {}
    for cline in clines:
        clineelement = cline.split(';')
        cid = clineelement[0]
        cname = clineelement[1]
        courseinfor[cid] = cname
    # print json.dumps(courseinfor,encoding='UTF-8',ensure_ascii=False)

with open('C:\Users\New\Desktop\\0008\\newfile.txt','w') as nf:
    tlist = teacherinfo.keys()
    clist = courseinfor.keys()
    for tid in tlist:
        for cid in clist:
            newline = teacherinfo[tid] + ':' + courseinfor[cid] + '\n'
            print newline
            nf.write(newline.encode('utf8'))






