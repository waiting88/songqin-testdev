import re
from collections import OrderedDict
def putInfoToDict(fileName):
    datas=OrderedDict()
    adict={}
    bdict={}
    with open(fileName,'r') as f:   
        for line in f:
            alist=[]
            adict["checkinttime"]=line.split(',')[0].strip().strip('(')
            adict["lessonid"]=line.split(',')[1]
            studentid=line.split(',')[2].strip().strip(')')
            alist.append(adict)
            if studentid not in datas:
                datas[studentid]=alist
            else:
                datas[studentid].append(adict)
    for key,value in datas.items():
        bdict[key]=value
    print bdict
 
               
               
               
