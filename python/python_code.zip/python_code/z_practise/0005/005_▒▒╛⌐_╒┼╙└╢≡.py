def putInfoToDict(fileName):
    f = open(fileName)
    retdict = {}
    for one in f.readlines():
        studentMessage = one.replace('(',' ').replace(')','').replace(';','').split(',')
        checkintime = studentMessage[0].strip()
        lessonid = studentMessage[1].strip()
        studentid = studentMessage[2].strip()
        if studentid not in retdict:
            retdict[studentid] = [{'lessonid':lessonid,'checkintime':checkintime}]
        else:
            retdict[studentid].append({'lessonid':lessonid,'checkintime':checkintime})
    import pprint
    pprint.pprint(retdict)
    return retdict

putInfoToDict('0005_1.txt')
