#coding:utf-8
from pprint import pprint
def putInfoToDict(fileName):
    with open(fileName,'r') as f:
#分行读取并去掉每行的换行符
        readf = f.read().splitlines()
        newf = []
        Dict = {}
        for line in readf:
            eachline = line.replace('(','').replace(')','').replace("'",'').replace("'",'')#处理每行多余的括号和引号
            eachline = eachline[:-1].split(',')

            #删除分割后，每行多余的最后一个逗号
            #print eachline
            newf.append(eachline)
        for one in newf:
                checkintime = one[0].strip()
                lessionid = one[1].strip()
                studentid = one[2].strip()
                infovalue = [{'lessionid':lessionid,'checkintime':checkintime}]
                if studentid not in Dict:
                    Dict[studentid] = infovalue
                else:
                    Dict[studentid].append(infovalue)
        pprint(Dict)

putInfoToDict('0005_1.txt')