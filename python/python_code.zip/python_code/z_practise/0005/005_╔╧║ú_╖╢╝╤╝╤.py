# -*- coding: UTF-8 -*-
__author__ = 'fjj'
import json
def putinfoToDict(fileName):
    with open(fileName, 'r') as f:
        f1 = f.readlines()
    List_lines = []
    Dict = {}
    for line in f1:
        line1 = line.replace('(', '').replace(')', '').replace("'", '').replace("'", '')
        List_lines.append(line1)
    for i in List_lines:
        collection = i[:-1].split(',')
        studentid = collection[2].strip()
        lessonid = collection[1].strip()
        checkintime = collection[0].strip()
        if studentid not in Dict:
            Dict[studentid] = [{'checkintime': checkintime, 'lessonid': lessonid}]
        else:
            Dict[studentid].append({'checkintime': checkintime, 'lessonid': lessonid})

    jsonDumpsIndentStr = json.dumps(Dict, indent=1)
    return jsonDumpsIndentStr


print putinfoToDict('E:/0005_1.txt')
