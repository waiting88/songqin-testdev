def putInfoToDict(fileName):
    with open(fileName, "r+") as fp:
        f = fp.readlines()

        id_list = []
        lesson_id_list = []
        time_list = []
        info_list = []

        for mess in f:

            mess = mess[2:-3]
            time = mess.split(",")[0]
            lesson = mess.split(",")[1]
            id = mess.split(",")[2]

            id_list.append(id)
            lesson_id_list.append(lesson)
            time_list.append(time)

            info = {}
            for i in range(len(id_list)):
                info["lessonid"] = id_list[i]
                info["checktime"] = time_list[i]
                info_list.append(info)

            jilu = {}
            for j in range(len(id_list)):
                jilu[id_list[j]] = info_list[j]
        return jilu


d = putInfoToDict("F:/0005_1.txt")
print d
