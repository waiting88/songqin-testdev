#!/usr/bin/env python
# -*- coding: utf-8 -*-
def putInfoToDict(fileName):
    with open(fileName,'r') as f:
        lines = f.readlines()
        dict = {}
        for line in lines:
             checkintime = line.split(',')[0]
             lessonid = line.split(',')[1]
             keyid = line.strip(';').split(',')[2]
             key = int(keyid.strip(')'))
             d= {'lessonid':int(lessonid),'checkintime':checkintime.strip('\t(\'')}
             dict.setdefault(key,[]).append(d)
        return dict

'''
dict = putInfoToDict('C:\\Users\\Administrator\\Desktop\\0005_1.txt')
print dict
'''

ret = putInfoToDict('0005_1.txt')

import pprint
pprint.PrettyPrinter(indent=4).pprint(ret)