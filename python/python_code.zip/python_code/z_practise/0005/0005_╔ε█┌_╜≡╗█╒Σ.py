def readdata(filename):
	dictdata={}
	lines=open(filename).readlines()
	for i in lines:
		dicti={}
		i = i.replace('(',' ')
		i = i.replace(')',' ')
		i = i.replace(',',' ')
		i = i.replace('\'',' ')
		i = i.replace(';', ' ')
		[day,time,lid,sid]=i.split()
		dicti['lensonid']=int(lid)
		dicti['checkintime']='%s %s' % (day,time)
		dictdata[int(sid)]=dicti
	print len(dictdata)
	return dictdata

print readdata('0005_1.txt')