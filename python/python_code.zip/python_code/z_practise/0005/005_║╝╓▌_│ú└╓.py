# coding:utf-8
def putInfoToDict(fileName):
    fl = open(fileName, "r")  # 读取文件中的内容
    result = fl.readlines()
    fl.close()
    rlt = (line.strip() for line in result)  # 去除文件中每行前后的空格
    dict_stu = {}  # 定义一个空字典存储所有学生的信息
    for line in rlt:
        list_value = []  # 定义一个空列表存储学生的签到信息
        dict_checkin = {}  # 定义一个空字典存储学生每次签到的信息
        value = line[1:-2].split(',')
        stuid = int(value[-1].strip())  # 获取学生的id
        lessionid = value[1].strip()  # 获取课程的id
        date_Time = value[0][1:-1].strip()  # 获取签到的时间
        dict_checkin["lessoinid"] = lessionid  # 往字典里面添加课程的id
        dict_checkin["checkintime"] = date_Time  # 往字典里面添加签到时间
        list_value.append(dict_checkin)  # 将字典里面每次的签到信息添加至列表里面

        if stuid in dict_stu:  # 判断学生id在字典中是否存在，并做出相应的处理
            dict_stu[stuid].append(dict_checkin)
        else:
            dict_stu.update({stuid: list_value})
    return dict_stu

fileName = "c:\\005.txt"
print putInfoToDict(fileName)
