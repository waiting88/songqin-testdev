#coding=utf-8
'''***** 编程题 0005 ******
现有一个数据库记录文件，
（见附件0005_1.txt），保存了学生课程签到的数据库记录。
其内容格式如下示例 所示：
(&#39;2017-03-13 11:50:09&#39;, 271, 131),
(&#39;2017-03-14 10:52:19&#39;, 273, 131),
(&#39;2017-03-13 11:50:19&#39;, 271, 126),
每一行记录保存了学生的一次签到信息。
每一次签到信息的记录，分为三个部分， 分别是签到时间、签到课程的id号、签到学生的id号
要求大家实现下面的函数。其中参数fileName 为 数据库记录文件路径， 输出结果是将数据库记录文件中的学生签到信息保存在一个字典对象中，并作为返回值返回。
def putInfoToDict(fileName):
要求返回的字典对象的格式是这样的， key 是各个学生的id号， value是 该学生的签到信息
    学生的签到信息是列表，里面保存着每个签到的信息
        每个签到的信息也是字典，有两个元素： key 是lessonid的 记录课程id，key是checkintime的 记录签到时间
比如，对于上面的示例中的3条记录，相应的返回结果如下：
{
    131: [
        {&#39;lessonid&#39;: 271,&#39;checkintime&#39;:&#39;2017-03-13 11:50:09&#39;},
        {&#39;lessonid&#39;: 273,&#39;checkintime&#39;:&#39;2017-03-14 10:52:19&#39;},
    ],
    126: [
        {&#39;lessonid&#39;: 271,&#39;checkintime&#39;:&#39;2017-03-13 11:50:19&#39;},
    ],
}'''
def putInfoToDict(fileName):
    with open(fileName, 'r') as txtfile:
        stuInfo = txtfile.read()#读取txt文件所有内容
        stuInfo = stuInfo.replace('\t', '').replace('\n', '')#去除空格和换行
        stuInfo = stuInfo[1:len(stuInfo) - 2]#去除前面的（和后面的）;
        stuList=stuInfo.split('),(')#根据),(号拆分数据
        dicStuInfo={}
        for valuse1 in stuList:
            stu=valuse1.split(',')
            # print stu
            checkintimeinfo = {}
            checkintimeinfo[stu[1].strip()]=stu[0].strip()
            dicStuInfo[stu[2].strip()]=checkintimeinfo
    return dicStuInfo


fileName='0005_1.txt'
print putInfoToDict(fileName)
