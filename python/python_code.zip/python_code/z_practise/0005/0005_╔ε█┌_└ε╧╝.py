# coding=utf-8
import json
from collections import defaultdict
# Define Function
def PutInfoToDict(fileName):

    #1.defind the path of file:
    FileOpenPath = fileName
    FileSavePath = "H:/python/PutSigninInfoToDict3.txt"
    fopen = open(FileOpenPath)
    fsave = open(FileSavePath, 'w')

    #2.Traversing eachchild element in the file as a list:
    dateLength = len('2017-03-13 11:50:09')
    DateList = []
    lessionIdAndStuIdList = []
    StuIdList = []
    lessionIdList = []

    AllLines = fopen.readlines()
    for one in AllLines:
        DateStartIndex = one.find('2017')
        DateEndIndex = DateStartIndex + dateLength
        date = one[DateStartIndex:DateEndIndex]
        DateList.append(date)

        ClassStartIndex = DateEndIndex + 3
        lessionIdAndStuId = one[ClassStartIndex:]
        lessionIdAndStuIdList.append(lessionIdAndStuId)    #lessionIdAndStuIdList  as if ['271, 131),\n', '271, 126),\n',]

    i = 0
    length = len(lessionIdAndStuIdList)
    while (i < length):
        AllId = lessionIdAndStuIdList[i].split(')')       #AllId  like this : ['271, 131', ',\n'] and ['271, 90', ',\n']
        LessionAndStuId = AllId[0].split(',')             #LessionAndStuId  like this : ['271', ' 131'] and ['271', ' 85']

        lessionId = LessionAndStuId[0].strip()            #lessionId  like this : 274
        StuId = LessionAndStuId[1].strip()                #StuId  like this  :  56
        StuIdList.append(StuId)                           #StuIdList  like this : ['131', '126', '85', '118', '119',....]
        lessionIdList.append(lessionId)                   #lessionIdList  like this : ['271', '271', '271',...]
        i += 1

    #3.Define the course number and check-in time as dictionary format:
    dic = {}
    LessionIdAndTimeList = []
    j = 0
    DateListLength = len(lessionIdList)
    while (j < DateListLength):
        dict = {'lessionid': lessionIdList[j], 'checkintime': DateList[j]}
        LessionIdAndTimeList.append(dict)                   #LessionIdAndTimeList  like this :
        j += 1                                                #[{'checkintime': '2017-03-13 11:50:09', 'lessionid': '271'},


    elementLen=len(LessionIdAndTimeList)
    Dict = {}
    m = n = 0
    DDict = {}
    LIST = []

    #4.The school number as the key,the third step of the dictionary format as the value to form a key-value pairs
    while (m < elementLen and n < elementLen):
        #ddict  like this : {131: {'checkintime': '2017-03-13 11:50:09', 'lessionid': '271'}}
        ddict = {}.fromkeys((int(StuIdList[n]),), LessionIdAndTimeList[m])
        #LIST like this : [{126: {'checkintime': '2017-03-13 11:50:19', 'lessionid': '271'}},........]
        LIST.append(ddict)
        n += 1
        m += 1

    #5.Convert the forth step of the list format to dictionary format
    DICT = {}
    for one in LIST:
        for k, v in one.items():
            DICT.setdefault(int(k), []).append(v),
            # module= [{k:v} for k,v in DICT.items()]
            printModule = json.dumps(DICT, indent=2)                      #format the dictionary
            #DICT like this : {128: [{'checkintime': '2017-03-13 11:51:44', 'lessionid': '271'}], 129: [{'checkintime': '2017.....

    #6.Write the final result to the file of PutSigninInfoToDict2.txt
    fsave.write('\n\n\n')
    fsave.write(printModule)
    fsave.flush()
    fopen.close()
    fsave.close()

#Call Function
PutInfoToDict('H:/python/0005_1.txt')