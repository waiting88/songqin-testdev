#encoding:utf-8
##############################################################################################################
# ** ** *编程题 0005 ** ** **
'''现有一个数据库记录文件，
（见附件0005_1.txt），保存了学生课程签到的数据库记录。
其内容格式如下示例
所示：
( '2017-03-13 11:50:09', 271, 131),
( '2017-03-14 10:52:19', 273, 131),
( '2017-03-13 11:50:19', 271, 126),
每一行记录保存了学生的一次签到信息。
每一次签到信息的记录，分为三个部分， 分别是签到时间、签到课程的id号、签到学生的id号
要求大家实现下面的函数。其中参数fileName为数据库记录文件路径， 输出结果是将数据库记录文件中的学生签到信息保存在一个字典对象中，并作为返回值返回。
def putInfoToDict(fileName):
    要求返回的字典对象的格式是这样的，
    key是各个学生的id号， value是该学生的签到信息

学生的签到信息是列表，里面保存着每个签到的信息
每个签到的信息也是字典，有两个元素： key是lessonid的记录课程id，key是checkintime的记录签到时间
比如，对于上面的示例中的3条记录，相应的返回结果如下：
{
    131: [
        { 'lessonid': 271,'checkintime':'2017-03-13 11:50:09'},
        { 'lessonid': 273,'checkintime':'2017-03-14 10:52:19'},
    ],

    126: [
        { 'lessonid': 271,'checkintime':'2017-03-13 11:50:19'},
    ],
}'''
##############################################################################################################

def putInfoToDict(fileName):
    with open(fileName+'/0005_1.txt', 'r') as db:
        student_sign = {}
        for oneline in db:
            if oneline.endswith('\n'): #判断是否为文件最后一行，最后一行无回车符
                a = oneline[1:-2]
            else:
                a = oneline[1:-1]
            one = eval(a)
            if one[2] in student_sign: #判断是否key已经存在，存在做插入操作，不存在新建（赋值）
                list = student_sign[one[2]]
                list.append({'lessonid': int(one[1]),'checkintime': one[0]})
            else:
                student_sign[one[2]] =[{'lessonid': int(one[1]),'checkintime': one[0]}]
    #print student_sign
    return student_sign


#调试putInfoToDict函数
#fileName = r'D:\Python27\test'
#a = putInfoToDict(fileName)
#print a