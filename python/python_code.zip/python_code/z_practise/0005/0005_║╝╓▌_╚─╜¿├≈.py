# coding=utf-8
def putInfoToDict(fileName):
    with open(fileName) as f1:
        studentDict = {}
        for line in f1.readlines():
            line1 = line.replace('\t', '')  # 去除开头的空格
            newline = line1.replace('\n', '')  # 去除换行符
            list = newline.split('(')[1].split(')')[0].split(',')  # 提取签到时间、课程和学号到到一个列表中
            list[0]=list[0].lstrip("'")
            list[0]=list[0].rstrip("'")#去除签到时间的引号
            checktime = list[0]  # 列表的第一个元素为签到时间
            lessonid = int(list[1])  # 列表的第二个元素为签到课程
            studentId = int(list[2])  # 列表的第三个元素为签到学号
            studentDict1 = {studentId: [{'lessonid': lessonid, 'checktime': checktime}]}
            if studentId in studentDict:
                studentDict[studentId].append(studentDict1[studentId][0])  # 判断字段中是否已经存在该学生的数据，如果存在则直接在该学号课程签到列表中增加一条数据
            else:
                studentDict.update(studentDict1)  # 如果不存在则直接添加到字典中
    print studentDict
    return studentDict

putInfoToDict('0005_1.txt')
