def putInfoToDict(fileName):
    with open(fileName) as f:
        allLines=f.readlines()
        for i in range(0,len(allLines)):
            lines=allLines[i].strip().split('\n')
            lines1=lines[0].replace("('","").replace("'","").strip().split(')')
            lines2=lines1[0].split(',')
            checkintime=lines2[0]
            lessonid=lines2[1]
            studentid=lines2[2]
            checkingInfo=[{'lessonid':lessonid,'checkingtime':checkintime}]
            dict={studentid:checkingInfo}
            print dict
			return dict
putInfoToDict('0005_1.txt')