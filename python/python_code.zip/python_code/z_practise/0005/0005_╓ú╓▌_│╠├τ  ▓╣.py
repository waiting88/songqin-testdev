#coding=utf8
#读取文件0005.txt，，存入变量content中，将变量记录到recordlist内容中

def putInfoToDict(fileName):
    with open(fileName) as f:
        content=f.read()
        recordlist=content.splitlines()

    #创建一个空的字典
    creDict={}

    #使用for循环取出userID，lessonid记录课程，checkintime签到时间
    for one in recordlist:
        #读取('2017-03-13 11:50:09', 271, 131),
        one= one.replace('(','').replace(')','').replace("''",'')
        cre=one.split(',')
        checkintime = cre[0].strip()
        lessonid    = cre[1].strip()
        userid      = cre[2].strip()


        #如果没有creDict字典，添加字典
        if userid not in creDict:
            creDict[userid]=[{'lessonid':lessonid,'checkintime':checkintime}]
        else:
            creDict[userid].append({'lessonid':lessonid,'checkintime':checkintime})

#引入pprint
    import pprint
    pprint.pprint(creDict)
    return creDict
putInfoToDict('0005_1.txt')