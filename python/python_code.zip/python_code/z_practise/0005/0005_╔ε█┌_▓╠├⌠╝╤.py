#coding=utf-8 
'''
现有一个数据库记录文件， 
0005_1.txt
7.83KB
下载
（见附件0005_1.txt），保存了学生课程签到的数据库记录。
其内容格式如下示例 所示：
(&#39;2017-03-13 11:50:09&#39;, 271, 131),
(&#39;2017-03-14 10:52:19&#39;, 273, 131),
(&#39;2017-03-13 11:50:19&#39;, 271, 126),
每一行记录保存了学生的一次签到信息。
每一次签到信息的记录，分为三个部分， 分别是签到时间、签到课程的id号、签到学生的id号
要求大家实现下面的函数。其中参数fileName 为 数据库记录文件路径， 输出结果是将数据库记录文件中的学生签到信息保存在一个字典对象中，并作为返回值返回。
def putInfoToDict(fileName):
要求返回的字典对象的格式是这样的， key 是各个学生的id号， value是 该学生的签到信息
    学生的签到信息是列表，里面保存着每个签到的信息 
        每个签到的信息也是字典，有两个元素： key 是lessonid的 记录课程id，key是checkintime的 记录签到时间
比如，对于上面的示例中的3条记录，相应的返回结果如下：
{
    131: [
        {&#39;lessonid&#39;: 271,&#39;checkintime&#39;:&#39;2017-03-13 11:50:09&#39;},
        {&#39;lessonid&#39;: 273,&#39;checkintime&#39;:&#39;2017-03-14 10:52:19&#39;},
    ],
    
    
    126: [
        {&#39;lessonid&#39;: 271,&#39;checkintime&#39;:&#39;2017-03-13 11:50:19&#39;},
    ],
    
}
'''
def putInfoToDict(fileName):
    with open(fileName,'r') as f:
         line_list=f.readlines()
         line_list=[x.strip('\n').strip("(") for x in line_list]
         line_list=[x.strip('\t') for x in line_list]
         line_list=[x.split(',') for x in line_list]
         #line_list最后两位为，和"
         time_list=[]
         id_list=[]
         lesson_list=[]
         #分割出各个关键字的列表
         for i in xrange(len(line_list)-2):
             time_list_str=str(line_list[i][0])
             id_list_str=str(line_list[i][-2])
             id_list.append(int(id_list_str.replace(')','')))
             time_list.append(time_list_str.replace('(','').replace(':','-'))
             lesson_list.append(str(line_list[i][1]))
        #每个签到的信息也是字典    
         register_list=list()
         for j in xrange(len(id_list)):
             register_list.append({'lessonid':int(lesson_list[j]),'checkintimer':time_list[j]})
         #学生签到信息列表元素是每个学生字典信息组成
         student_message_list=[]
         for k in xrange(len(register_list)):
             student_message_list.append({id_list[k]:register_list[k]})
         #学生签到信息保存在一个字典对象中，并作为返回值返回
         student_message_dict={}
         for x in xrange(len(student_message_list)):
             for k,v in student_message_list[x].items():
                 student_message_dict.setdefault(k,[]).append(v)
         print student_message_dict
         return student_message_dict
            
fileName1= "0005_1.txt"
putInfoToDict(fileName1)             
           
             
           
         
        
         
         
         
         
         
         
         
