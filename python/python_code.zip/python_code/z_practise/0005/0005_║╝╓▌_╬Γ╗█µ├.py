import os
os.getcwd()
with open('0005_1.txt','r') as f:
    content =f.read()
    dict = content.split('\n\t')
new_dict = {}
for i in dict:
    i=i.replace('(','').replace(')','').replace("'",'').replace('\t','').replace('\\','')
    cheakintime =i.split(',')[0]
    lessonid =i.split(',')[1]
    userid =i.split(',')[2]
    if userid not in new_dict:
        new_dict[userid]=[{'lessonid':lessonid,'cheakintime':cheakintime}]
    else:
        new_dict[userid].append({'lessonid':lessonid,'cheakintime':cheakintime})
import pprint
pprint.pprint(new_dict)