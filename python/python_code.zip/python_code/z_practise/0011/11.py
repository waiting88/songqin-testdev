#coding=utf8
import requests,threading

url1 = 'http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt'
url2 = 'http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt'
readme = []
readme_lock = threading.Lock()
def getUrl1data():
    r1 = requests.get(url1)
    # print type(r)
    # print r.encoding
    #print(r1.text)
    readme_lock.acquire()
    readme.append(r1.text)
    print 'file1 is ok'
    print readme
    readme_lock.release()


def getUrl2data():
    r2 = requests.get(url2)
    # print type(r)
    # print r.encoding
    #print(r2.text)
    readme_lock.acquire()
    readme.append(r2.text)
    print 'file2 is ok'
    print readme
    readme_lock.release()
t1 = threading.Thread(target=getUrl1data())
t2 = threading.Thread(target=getUrl2data())
t1.start()
t2.start()
t1.join()
t2.join()

print  readme
f1=open('readme89.TXT','w')
for i in readme:
    f1.writelines(i)
f1.close()
print 'readme89 is ok'
# h1=getUrl1data()
# h2=getUrl2data()

