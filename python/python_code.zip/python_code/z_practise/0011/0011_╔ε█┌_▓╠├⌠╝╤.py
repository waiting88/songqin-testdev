#coding=utf-8
'''
阅读下面的两个知识点:
1. ffmpeg可以用下面的参数来录制Windows 桌面操作的视频。
ffmpeg.exe -y -rtbufsize 100M -f gdigrab -framerate 20 -draw_mouse 1 -i desktop -c:v libx264 -r 20 -crf 35 -pix_fmt yuv420p -fs 100M &quot;fffffffffffffffff&quot;
其中 fffffffffffffffff 部分 是需要填入 产生的视频文件名。
录制过程中，用户按键盘 q 键，可以退出录制。
2. ffmpeg还可以用来合并视频文件，windows下面的格式如下
ffmpeg.exe -f concat -i concat.txt -codec copy out.mp4
其中concat.txt 是要合并视频的文件列表。格式如下，每行以file 开头 后面是要合并的视频文件名：
file 20170330_110818.mp4
file 20170330_110833.mp4
------------------------------
下载ffmpeg程序
ffmpeg.zip
15.05MB
下载
要求大家写一个python程序，运行后提示用户是要做什么操作，如下
 &#39;请选择您要做的操作：1：录制视频，2：合并视频：&#39;

 如果用户输入1并回车， 则调用ffmpeg录制视频文件，产生在当前目录下面。要求录制的视频文件名 是当前时间（年月日_时分秒.mp4格式），比如 &#39;20170330_093612.mp4&#39; （怎么产生这种时间格式的字符串，不知道的请网上搜索方法）

 如果用户输入2并回车，则按字母顺序列出当前目录下所有的 mp4为扩展名的视频文件(怎么列出，请自行网上搜索方法)，并在前面编上序号。如下所示

 ---------------------------------
    目录中有这些视频文件：
    1 - 20170329_202814.mp4
    2 - 20170330_093251.mp4
    3 - 20170330_093612.mp4
    请选择要合并视频的视频文件序号(格式 1,2,3,4) :
 ---------------------------------
 用户输入视频序号（序号以逗号隔开）后， 程序合并视频文件， 输出的合并后视频文件名 固定为 out.mp41

'''
import datetime,time,os
def show_file():

    return newname_list

choice=int(raw_input('1：录制视频，2：合并视频'))
if choice==1:
    outputfile = r'E:\py\新建文件夹\0008_深圳_蔡敏佳\0008_深圳_蔡敏佳' + datetime.datetime.now().strftime('%Y%m%d_%H:%M:%S')+'.mp4'
    ffmpegDir = r'E:\py\新建文件夹\0008_深圳_蔡敏佳\0008_深圳_蔡敏佳\ffmpeg.exe'
    settings = [
        '-y -rtbufsize 100M -f gdigrab -framerate 20 ',
        '-draw_mouse 1 -i desktop -c:v libx264 ',
        '-r 20 -crf 35',
        ' -pix_fmt yuv420p -fs 100M + "%s" ' % outputfile
    ]
    recordingCmdLine=''.join([ffmpegDir]+settings)
    os.system(recordingCmdLine)

else:
    i=1
    newname_list=[]
    new_list=[]
    files = os.listdir(".")
    for filename in files:
        portion = os.path.splitext(filename)
        # 如果后缀是.mp4
        while portion[1] == ".mp4":
            # 重新组合文件名
            newname = '%s %s%s' %(i,'-',filename)
            i+=1
            print newname
            newname_list.append(newname)
    print newname_list
    num= raw_input('输入视频序号（序号以逗号隔开）')
    num=num.split(',')
    for one in  newname_list:
        one1=one.split('-')
        if one1[0] in num:
            new_name='file'+str(one1[1])
            new_list.append(new_name)
    with open('concat.txt','w') as f:
        for x in new_list:
            f.writelines(x)
    ffmpegDir = r'E:\py\新建文件夹\0008_深圳_蔡敏佳\0008_深圳_蔡敏佳\ffmpeg.exe'
    settings = [ 'ffmpeg.exe -f concat -i concat.txt -codec copy out.mp4 ',]
    recordingCmdLine=''.join([ffmpegDir]+settings)
    os.system(recordingCmdLine)








