#coding:utf-8
import os,time

#定义一个方法用于录制视频
def recording():
    #工具的目录
    ffmpegDir = "d:/luping/ffmpeg.exe"
    # 文件的保存位置
    curtime = time.strftime("%Y%m%d_%H%M%S", time.localtime())
    fileName = u"d:/luping/" + curtime + ".mp4"
    setting=["-y","-rtbufsize 100M","-f gdigrab","-framerate 20","-draw_mouse 1","-i desktop","-c:v libx264","-r 20"
             ,"-crf 35","-pix_fmt yuv420p","-fs 100M"]
    cmdlines=" ".join([ffmpegDir]+setting)+' "%s"'%fileName
    print cmdlines
    os.system(cmdlines)
#定义一个方法用于合并视频
def together():
    dir_fname="d:/luping"
    dir=os.listdir(dir_fname)
    dirdict={}
    num = 1
    print u"目录中有这些视频文件"
    for line in dir:
        if line.endswith(".mp4"):
            rlt="%d - %s"%(num,line)
            print rlt
            dirdict[num]=line
            num += 1
    tishi= u"请选择要合并视频的视频文件序号（格式：1，2，3，4）:"
    input=raw_input(tishi)
    with open("d:/luping/concat.txt",'w') as inputname:
        for i in input.split(','):
            i=int(i)
            mp4name="file %s\n"%(dirdict[i])
            inputname.write(mp4name)
    os.system("d:/luping/ffmpeg.exe -f concat -i d:/luping/concat.txt -codec copy d:/luping/pipi.mp4")

if __name__=="__main__":
    output=u'''请选择您要做的操作：1.录制视频
                    2.合并视频
                                 '''
    try:
        input=raw_input(output)
        if input==str(1):
             recording()
        elif input==str(2):
            together()
    except Exception,e:
        print e