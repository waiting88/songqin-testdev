#coding=utf-8
import time,os

#录制视频
def record():
	outputfile='D:\\tmp\\'+ time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time())) + '.mp4'

	ffmpegdir=r'D:\tools\ffmpeg-win32-static\bin\ffmpeg.exe'

	settings=[
		'-y -rtbufsize 100M -f gdigrab -framerate 20',
		'-draw_mouse 1 -i desktop -c:v libx264',
		'-r 20 -crf 35 -pix_fmt yuv420p -fs 100M -movflags +faststart "%s"' % outputfile
	]
	recordingcmdline=' '.join([ffmpegdir]+settings)

	print recordingcmdline
	os.system(recordingcmdline)

#遍历*.mp4后缀名的文件
def getFileName(path):
    ''' 获取指定目录下的所有指定后缀的文件名 '''
    # print __name__
    f_list = os.listdir(path)
    # print type(f_list)
    f1=[]
    i=1
    for f in f_list:
        # os.path.splitext():分离文件名与扩展名
        if os.path.splitext(f)[1] == '.mp4':
            # print '%s - %s'%(i,f)
            f1.append(f)
            i += 1
    # print type(f)f=f.split('\n')
    # print f.append(os.path.splitext(f)[1])
    return f1

#按序号列出.mp4文件
def sortFileName(path):
	# path = 'D:\\tmp\\'
	i=0
	f1 = []
	for f in getFileName(path):
		# print '{} - {}'.format(i, f)
		if i < len(getFileName(path)):
			# print '{} - {}'.format(i+1, f)
			s='{} - {}'.format(i+1, f)
			print s
			f1.append(s)
			i+=1
	return f1

#写.mp4后缀名文件到contcat.txt中
def writeFileName(flist,ulist):
	# print __name__
	# path = 'D:\\tmp\\'
	u_index=0
	#f_write=[]
	a=getFileName(path)
	with open('D:\\tmp\concat.txt', 'w+') as f:
		for u in ulist:
			u_index += 1
			if int(u) > len(a):
				print '第%s个输入有误!' % u_index
				return False
			f.write('file' + ' ' + a[int(u)-1] + '\n')

	return True

#合并视频
def merge():
	outputfile='D:\\tmp\\merge\\'+ 'out'+'.mp4'
	ffmpegdir=r'D:\tools\ffmpeg-win32-static\bin\ffmpeg.exe'

	settings=[
		'-f concat -i D:/tmp/concat.txt -codec copy "%s"' % outputfile
	]

	mergecmdline=' '.join([ffmpegdir]+settings)

	print mergecmdline
	os.system(mergecmdline)

path = 'D:\\tmp\\'
while True:
	print u'请选择您要做的操作:1:录制视频,2:合并视频:',

	if raw_input()=='1':
		# break
		record()
		if raw_input()=='q':
			break

	else:
		print '------------------------'
		print u'目录中有这些视频文件:'
		filelist=sortFileName(path)

		print u'请选择要合并视频的视频文件序号(格式如1,2,3,4):'
		print '------------------------'
		ustr=raw_input()
		u_list=ustr.split(',')

		if writeFileName(filelist,u_list)==False:
			# print u'输入有误!请重新输入!'
			continue
		merge()
		if raw_input():
			break
		# break