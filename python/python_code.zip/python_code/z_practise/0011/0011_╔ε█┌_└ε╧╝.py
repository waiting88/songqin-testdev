# coding=utf8
#经验教训1打开的文件一定要记得关闭，否则后面的很多错误（如：无法成功读取或写入）都是没有关闭原来打开的文件造成的
#经验教训2报错‘invalid  data found’，是因为最后合并视屏的文件concat.txt中最后一行为空行
#是之前对concat.txt文件进行写操作时 ，没写一次都加入'\n'造成的,所以当要对concat.txt文件操作时就会失败
#所以一定要对其进行去除最后一行空行的操作
#经验教训3程序健壮性太差，有待改进
import time
import os
import sys
# 输出视屏文件
outputfile =time.strftime('%Y%m%d_%H%M%S', time.localtime()) + '.mp4'
# 工具目录
ffmpegDir = 'H:/PYTHON/ffmpeg.exe'
settings1 = [
    '-y -rtbufsize 100M -f gdigrab -framerate 25',
    '-offset_x 400 -offset_y 0 -video_size 640*480',
    '-draw_mouse 1 -i desktop -c:v libx264',
    '-r 20 -preset medium -tune zerolatency -crf 25',
    '-pix_fmt yuv420p -fs 100M "%s" ' % outputfile
]
recordingcmdLine1 = ' '.join([ffmpegDir] + settings1)

choice = raw_input("请选择您要做的操作：1：录制视屏，2：合并视屏:")
if choice == '1':
    print 'recordingcmdLine1'
    os.system(recordingcmdLine1)

else:
    # #列出目录中扩名为MP4的文件，并将结果按指定格式（序号 - 视频文件名）存入videofile.txt中
    def listdir(dir, vfile):
        list=os.listdir(dir)
        # print list
        i=1
        for one in list:
            if one.endswith('.mp4'):
                vfile.write(str(i) + ' ' + '-' + ' ' + one + '\n')
                i+=1

    dir='H:\TestDevelop\python'
    vfile = open('videofile.txt', 'w')
    listdir(dir,vfile)
    vfile.close()

    #在终端输出目录中已有的视屏文件，即videofile.txt中存储的视频文件名， 已便用户选择想要合并的视频
    print "目录中有这些视屏文件:"
    fopen=open('videofile.txt')
    allLines=fopen.readlines()

    #将视频序号作为key,视屏名字作为value，形成字典的键值对，以便后续用户输入视频序号时，可以读取和保存对应的视屏名字
    videoNumDict={}
    for one in allLines:
        print one
        videoNumDict[one[0]] = one[4:].strip(',').strip('\n')

    #让用户输入需要合并的视屏的编号
    choiceNumber=raw_input('请选择要合并视屏的视屏文件序号(格式1,2,3,4)：')
    choiceNumber = choiceNumber.split(',')

    # 判断用户输入的所要合并的视屏编号是否存在
    ffmfile = open('concat1.txt', 'w+')
    for num in choiceNumber:
        if num  not in  videoNumDict.keys()  :
            continue
        ffmfile.writelines('file'+ ' ' + videoNumDict[num]+'\n' )
    ffmfile.close()                                        #一定要记得关闭之后再使用

     #去除concat.txt文件中的最后一个空行
    fout = open('concat1.txt','r')
    fin = open('concat.txt','w')
    lines = fout.readlines()
    fin.writelines(lines[0:-1])
    fin.writelines(lines[-1].replace('\n', ''))           #writelines（sequence）方法
    fin.close()
    fout.close()

    #调用程序，开始合并视屏
    settings2 = ['-f concat -i concat.txt -codec copy out.mp4']
    recordingcmdLine2 = ' '.join([ffmpegDir] + settings2)
    print 'recordingcmdLine2'
    os.system(recordingcmdLine2)



















