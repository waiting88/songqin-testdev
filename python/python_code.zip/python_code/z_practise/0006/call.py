import sys
import pprint
sys.path.append(r"D:\gsync\workspace\sq\python\samples\z_practise\0006\practise")

from phone.samsung.note.galaxy_note7 import askPrice

pprint.pprint(sys.path)
askPrice()


