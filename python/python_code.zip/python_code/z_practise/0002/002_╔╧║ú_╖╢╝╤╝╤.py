# -*- coding: UTF-8 -*-
__author__ = 'fjj'
# 第一种：函数法
def func(list):
    newlist = []
    length = len(list)
    for i in range(length):
        min_digit = min(list)
        list.remove(min_digit)
        newlist.append(min_digit)
    return newlist


list1 = [4, 2, 1, 9, 5, 8]
print "list is:   ", list1
print "newlist is:", func(list1)
'''

#第二种：冒泡排序法
def func(list):
    length=len(list)
    for i in range(length):
        for j in range(length):
            if list[i]<list[j]:
                list[i],list[j]=list[j],list[i]
    newlist=list
    return newlist
list1=[4,2,1,9,5,8]
print "list is:   ",list1
print "newlist is:",func(list1)'''
