inputstu= raw_input('Please enter the information of students like this : Name1 , Age1 ; Name2 , Age2;...')

stu = inputstu.split(';')
stu_ = stu[:2]
stu_1 = stu_[0].split(',')
stu_2 = stu_[1].split(',')
   
fx = '''
    %-20s:%02d 
    %-20s:%02d
'''
students = fx % (stu_1[0].strip(),int(stu_1[1]),stu_2[0].strip(),int(stu_2[1]))
print students