#coding:utf-8

def PersonId():
    TotalId = []
    while True:

        while True:
            print "Please input your name without whitespace>"
            Name = raw_input("")
            if len(Name) <= 20 and Name.isalpha() == True:
                perName = '{:<20}'.format(Name.strip())
                break
            else:
                print "The length of name <= 20 and must be alpha,please input again. "

        while True:
            print "Please input your age>"
            Age = raw_input()
            if Age.isdigit() == True:
                perAge = '{:0>2}'.format(Age.strip())
                break
            else:
                print "The age must be integer,please inout again."

        PerId = perName + ':' + perAge + ';'
        TotalId.append(PerId)
        for one in TotalId:
            print one

PersonId()

