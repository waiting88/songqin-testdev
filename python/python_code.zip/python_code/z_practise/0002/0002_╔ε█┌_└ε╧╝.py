# coding=utf-8
"""
1.提示用户输入学生年龄信息 格式如下：
Jack Green ,   21  ;  Mike Mos, 9; 
信息全部由英文字符组成。
学生信息之间用分号隔开（分号前后可能有不定数量的空格），学生姓名长度最多不超过20个字符。 
每个学生信息里的 姓名和 年龄之间用 逗号隔开（逗号前后可能有不定数量的空格） 。 
输入学生的数量不限
2. 将输入的学生信息分行显示，格式如下
Jack Green :   21; 
Mike Mos   :   09; 
学生的姓名要求左对齐，宽度为20， 年龄信息右对齐，宽度为2位，不足前面补零

"""

print "You enter the information of the form must like this : name1 , age1 ; name2 , age2 ; ..... "
print "ps:逗号和分号前后的空格数量没有限制"
StudensInfo = raw_input("Please enter student's information :")         # 让用户输入学生信息
StuInfo = StudensInfo.split(';')                                        # 用split(';')方法将每个学生信息隔开
#print StuInfo
AllStuList = []                                                         # 定义一个容纳所有学生信息的大列表

for SI in StuInfo:                                           # 遍历学生信息
    StuList = SI.split(',')                                   # 用split(',')方法将单个学生信息的姓名和年龄隔开放在一个小列表里面
    #print StuList
    AllStuList.append(StuList)                                # 将小列表里面的单个学生的信息追加在大列表里面作为子元素
#print AllStuList
length = len(AllStuList)
i = 0
while (i < length):
    #print '%-20s : %02d' % (AllStuList[i][0].strip(), int(AllStuList[i][1]))  # 循环遍历输出学生信息并去除逗号与分号前后的不定量空格
    print '{:<10}:{:<2}'.format(AllStuList[i][0].strip(), int(AllStuList[i][1]))
    i +=1