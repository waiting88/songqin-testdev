# coding=utf-8
def zuoye2():

    student = raw_input('请输入学生姓名和年龄，学生信息之间用分号隔开和结尾,姓名和年龄之间用逗号隔开,'
                        '\n格式如 Jack Green ,21;Mike Mos,9;   :').split(';')
    for i in student:
        if i != student[-1]:  #输入的学生信息是以；结尾，最后一个是空的，去掉不要
            y = i.split(',')
            x = y[0].strip()
            z = y[1].strip()
            print '{:<20}：{:>02};'.format(x, z);
zuoye2()