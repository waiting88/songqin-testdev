# coding=utf-8
data = raw_input("please input data:")  # 数据输入
data = data.replace(' ', '')# 去除字符串中的空格
datalist = data.split(";")# 把输入的字符串分割成列表
del datalist[-1]  # 删除列表最后一个空元素
newlist = []
for x in datalist:
    newlist.append(x.split(","))  # 把datalist转换成一个二维列表放在newlist里
for one in newlist:
    print "%-20s: %02d" % (one[0], int(one[1]))
