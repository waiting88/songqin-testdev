student =raw_input('please input your name and your year:')
name = student.split(';')
for i in name:
    if len(i)!=0:
        name1 = i.split(',')
        print '%-020s:%02d;' % (name1[0].strip(),int(name1[1].strip()))


