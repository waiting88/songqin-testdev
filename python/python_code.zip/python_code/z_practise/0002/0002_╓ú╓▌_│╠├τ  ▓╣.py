#第一个编程题没有写出来，只写出来第二个编程题

#第二个编程题
studentName=[('Jack Green',21),('Mike Mos',9)]

sn='''
%-20s :%02d;
%-20s :%02d;
'''

print sn % (studentName[0][0],studentName[0][1],studentName[1][0],studentName[1][1])