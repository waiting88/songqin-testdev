strList = raw_input("please input student's message like Jack Green ,   21  ;  Mike Mos, 9;;")
strList_message = strList.split(';')
for i in range(len(strList_message)-1):
    str = strList_message[i].strip()
    str2 = str.split(',')
    str3 = str2[0].strip()
    str4 = str2[1].strip()
    print "%-20s:%02d;" % (str3,int(str4))

