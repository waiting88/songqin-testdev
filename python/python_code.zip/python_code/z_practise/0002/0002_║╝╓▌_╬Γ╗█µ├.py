one = raw_input('Please enter your name and age:')
two = []
two = one.split(';')
for message in two:
    message1 = message.split(',')
    print '%-20s:%02d;' % (message1[0].strip(),int(message1[1].strip()))