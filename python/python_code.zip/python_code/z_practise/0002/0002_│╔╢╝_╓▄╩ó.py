def GetnameAge(s):
    get_s = s.split(';')
    a1 = get_s[0].rstrip()
    a2 = get_s[1].lstrip()
    a3 = a1.split(',')
    a4 = a2.split(',')
    a5 = a3[0].rstrip()
    a6 = a3[1].lstrip()
    a7 = a4[0].rstrip()
    a8 = a4[1].lstrip()
    ps = '%-20s:%02d\n%-20s:%02d'
    print ps % (a3[0],int(a3[1]),a4[0],int(a4[1]))
s = raw_input('Please input name and age:')
GetnameAge(s)

