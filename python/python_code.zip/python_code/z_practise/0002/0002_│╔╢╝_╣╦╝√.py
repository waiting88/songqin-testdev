name_age = raw_input('please enter your name and age:').split(';')
for one in name_age:
    print '%-20s:%02d;'% (one.split(',')[0],int(one.split(',')[1]))