student_information=raw_input()
a=student_information.split(';')
for i in xrange(len(a)-1):
    b=str(a[i])
    c=b.replace(' ','')  
    d=c.split(',')
    print "%-20s:%02d;" %(d[0],int(d[len(d)-1]))
    

 
