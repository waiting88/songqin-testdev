Total = ''
while True:
    Name = raw_input('please your namme:')
    Age = raw_input('please your age:')
    infor1 = '{:<20},{:0>2};\n'.format(Name , Age)
    Total = infor1 + Total
    print Total
