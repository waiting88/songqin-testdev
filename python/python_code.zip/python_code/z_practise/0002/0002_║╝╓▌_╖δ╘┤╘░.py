# -*-coding:utf-8-*-
a = raw_input("Enter your name and age")
b = a.split(';')
for one in b:
    b=one.split(',')
    name=b[0].lstrip()
    age=b[1].lstrip()
    print '%-20s,%02d;'%(name,int(age))