
def students():
    name_age=raw_input("please enter your name and age:")
    n_a= name_age.split(";")
    n_a.pop(-1)
    
    for i in n_a:
        
        name=i.split(",")[0]
        age=i.split(",")[1]
        print "%-20s:%02d;"%(name.strip(),int(age.strip()))

students()
