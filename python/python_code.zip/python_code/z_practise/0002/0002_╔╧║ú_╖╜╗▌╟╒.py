students = raw_input('please input:name,age;').split(';')
for student in students:
     name = student.split(',')[0]
     if name != '':
          age = student.split(',')[1]
          print '%-20s:%2s;' % (name.strip(), age.strip())
     else:
          pass
