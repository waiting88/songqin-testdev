
str=raw_input("enter your str:\n")

list1=str.strip(';').split(';')
for one in list1:
    print ";".join(one.split(","))+";"
