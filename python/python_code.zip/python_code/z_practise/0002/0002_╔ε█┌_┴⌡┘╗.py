print('Please input the students information in turn(name,age;): ')
stuInformation=raw_input()
stuInformation=stuInformation.strip().split(';')
for i in range(0,len(stuInformation)-1):
    oneStu=stuInformation[i].strip().split(',')
	print '%-20s:%s;'%(oneStu[0],oneStu[1])
	