#!/usr/bin/env python2
# -*- coding: utf-8 -*-
i=0
while(True):
    if (i== 0):
        print "Please your name and age,input N to quit:\n Format eg:A,20;B21;C,22 \n"
        i=1
    Stu = raw_input("Please your name and age,input N to quit to finish:")
    if(Stu == 'N'):             #输入大写N，打印已输入的学生信息，并退出输入行
        break
    
    Stu2=Stu.strip(' ;').split(';')
    for stu in Stu2:
        fs = "%-20s : %020d"
        
        if len(stu.split(',')) !=2:     #学生的姓名和年龄信息为空时，只打印有姓名和年龄的学生信息
            continue
        name=stu.split(',')[0].strip()
        age=int((stu.split(',')[1]).strip())

        if len(name)>20:
            name = name[:20]
        if age >= 100 or age <=0 :
            print 'Errror!Please again input your age.'
            raw_input("Please your name and age,input N to quit to finish:")

      	print fs % (stu.split(',')[0].strip(), int(stu.split(',')[1].strip()))
           
            
