#coding:utf-8

import requests,time,threading
#设置个全局变量来存储获取的文本内容
content = []
#设置一个锁控制全局变量
content_lock = threading.Lock()
def request1():
    r1 = requests.get('http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt')
    time.sleep(1)
    text1 = r1.text
    #要访问全局变量，此时获取锁
    content_lock.acquire()
    content.append(text1)
    #使用完毕，释放锁
    content_lock.release()

def request2():
    r2 = requests.get('http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt')
    time.sleep(1)
    text2 = r2.text
    content_lock.acquire()
    content.append(text2)
    content_lock.release()

if __name__ == '__main__':
    t1 = threading.Thread(target=request1)
    t2 = threading.Thread(target=request2)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    with open('concat_content.txt','w') as f:
        Content = content[0]
        f.write(Content)


