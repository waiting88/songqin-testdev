#coding=utf-8
'''***** 编程题 0013 ******
先阅读下面关于Python requests库的文章 ，了解 使用它去获取一个网页内容的方法。
http://docs.python-requests.org/zh_CN/latest/user/quickstart.html
然后编写一个python程序，创建两个子线程，分别到下面的网址获取文本内容
http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt
http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt
主线程等待这个两个子线程获取到信息后，将其内容合并后存入名为 readme89.TXT 的文件中'''


#导入模块

from time import sleep
import threading
import requests
import os
#获取网页
# getweb1=requests.get("http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt")
# getweb2=requests.get("http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt")
# print getweb1.text
#调用 Lock函数，返回一个锁对象
mutex = threading.Lock()# 创建锁
global textcontentlist# 定义全局变量
textcontentlist=[]

def thread_entry(url):
    #获取锁
    mutex.acquire()
    textcontentlist.append(requests.get(url).text)
    #释放锁
    mutex.release()

if __name__ == '__main__':
    print 'main thread start.'
    urllist=["http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt","http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt"]
    #i=0
    # while i<len(urllist):
    #     temp="thread%s" % (i)
    #     temp = threading.Thread(target=thread_entry, args=(urllist[i],))
    #     sleep(1)
    #     temp.start()
    #     i+=1

    t1=threading.Thread(target=thread_entry, args=(urllist[0],))
    t2 = threading.Thread(target=thread_entry, args=(urllist[1],))
    t1.start()
    sleep(1)
    t2.start()
    t1.join()
    t2.join()

    if os.path.exists("./readme89.TXT"):#判断文件是否存在
       #存在，删除文件
       print "存在"
       os.remove("./readme89.TXT")
    with open("./readme89.TXT", "a+")as f1:
        for i in textcontentlist:
         f1.write(i+"\n")
    print 'main thread end.'












     # 定义全局变量
    # global mutex
    # # 创建锁
    # mutex = threading.Lock()
    # url1="http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt"
    # url2="http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt"
    # t1 = threading.Thread(target=thread_enter,args=(url1))
    # print t1.start()
    # t1.join()
    # print "t1 end"
    # # # 取得锁
    # # mutex.acquire()
    # # with open("./readme89.TXT", "a+")as f1:
    # #     f1.write()
    # # # 释放锁
    # # mutex.release()
    #
    #
    #
    # # t2 = threading.Thread(target=thread_enter,args=(url2))
    # # t2.start()
    #
    # # t2.join()
    # # print "t2 end"
    # print 'main thread end.'

