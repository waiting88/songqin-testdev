#coding:utf-8
import time,threading
import requests
#线程1：用于获取第1个网址的文本内容并存入全局的变量中
def thread_1(url1):
    rt=requests.get(url1)
    url1_text=rt.text
    thread_lock.acquire()
    result.append(url1_text)
    thread_lock.release()
#线程2：用于获取第2个网址的文本内容并存入全局的变量中
def thread_2(url2):
    rt = requests.get(url2)
    url2_text = rt.text
    thread_lock.acquire()
    result.append(url2_text)
    thread_lock.release()
if __name__=="__main__":
    url1 = "http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt"
    url2 = "http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt"
    result=[]
    thread_lock = threading.Lock()
    th1=threading.Thread(target=thread_1, args=(url1,))
    th2=threading.Thread(target=thread_2,args=(url2,))
    th1.start()
    th2.start()
    th1.join()
    th2.join()
    for i in result:
        with open("d:/readme89.txt", "a") as fl:
            fl.write(i+'\n')