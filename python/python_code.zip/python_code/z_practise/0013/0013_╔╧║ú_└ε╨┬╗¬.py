#coding=utf8
import requests
import threading
import time
def getSource(url,path):
    r=requests.get(url)
    time.sleep(2)
    s= r.text
    with open(path,'a') as f:
        f.write(s)
if __name__=='__main__':
    url1='http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt'
    url2='http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt'
    path='c:/python27/test/readme89.TXT'
    t1=threading.Thread(target=getSource,args=(url1,path,))
    t2=threading.Thread(target=getSource,args=(url2,path,))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

