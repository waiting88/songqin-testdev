# coding=utf8
import requests
import threading
from time import sleep
conList = []
def content1():
    print "start content1"
    R = requests.get('http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt')
    conList.append(R.text)
    print  conList
    sleep(2)

def content2():
    print "start content2"
    W = requests.get('http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt')
    conList.append(W.text)
    print  conList
    sleep(1)



if __name__=='__main__':
    t1 = threading.Thread(target=content1)
    t2 = threading.Thread(target=content2)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    with open('readme89.TXT.txt', 'w') as f1:
        for one in conList:
            f1.writelines(one)
