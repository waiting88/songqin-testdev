# coding=utf8
import threading
import requests
from time import sleep, ctime
f=open('readme89.txt','a')
#调用Lock函数，返回一个锁对象，
#理解问题：该函数并不是所住哪个对象，而是在获取锁与释放锁之间的代码，在这段代码内，对哪个对象操作就锁住了哪个对象。
f_lock = threading.Lock()
def thread1_entry(url1):
    #发送请求1
    r1=requests.get(url1)
    #获取请求1的响应内容
    content1=r1.text
    #在代码访问共享对象之前加锁
    f_lock.acquire()
    #当多个线程同时执行lock.acquire()时，
    # 只有一个线程能成功获取锁，然后继续执行代码
    #其他线程就继续等待，直到获得锁为止
    f.write(content1)
    #访问完共享对象 释放锁
    f_lock.release()
    #访问结束后，一定要调用Lock对象的acquire方法来解锁
    #否则其他等待锁的线程将永远等待下去，成为死线程
def thread2_entry(url2):
    #发送请求2
    r2=requests.get(url2)
    # 获取请求2的响应内容
    content2=r2.text
    #在代码访问共享对象之前加锁
    f_lock.acquire()
    f.write(content2)
    #访问完共享对象 释放锁
    f_lock.release()


if __name__ == '__main__':
    print 'main thread start'
    #创建线程对象，指定了线程的入口函数
    t1=threading.Thread(target=thread1_entry,args=("http://mirrors.163.com/centos/6.8/isos/x86_64/README.txt",))
    t2=threading.Thread(target=thread2_entry,args=("http://mirrors.163.com/centos/6.9/isos/x86_64/README.txt",))
    #启动新线程
    t1.start()
    t2.start()
    #等待t1,t2线程结束
    t1.join()
    t2.join()
    f.close()
    print 'main thread end'
