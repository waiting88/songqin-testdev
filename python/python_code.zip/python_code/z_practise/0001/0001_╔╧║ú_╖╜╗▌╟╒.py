#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''#方法一
def getname(srcstr,b = [],c = ''):
    b=srcstr.split(',')
    c = b[1].strip('the name is')
    return c
'''

#方法二
def getname(srcstr,step1=0,step2=0,c=''):
    step1=srcstr.find('the name is')
    step2=srcstr.rfind(',')
    c=srcstr[step1+12:step2]
    return c

