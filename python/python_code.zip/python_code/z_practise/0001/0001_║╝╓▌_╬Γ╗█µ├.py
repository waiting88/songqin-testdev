def getName(srcStr):
	return srcStr[srcStr.find('the name is')+12:srcStr.find(',',srcStr.find('the name is'))]

print getName('001 come in ,the name is jack,level 9')

