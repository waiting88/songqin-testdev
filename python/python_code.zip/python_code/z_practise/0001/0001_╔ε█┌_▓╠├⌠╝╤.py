def getName(srcStr):
    a=srcStr.find("the name is")
    b=srcStr[a:]
    c=b.split()
    Name=c[3].replace(",","")
    print Name
STR="A pretty boy come in, the name is Patrick, level 194"
getName(STR)
