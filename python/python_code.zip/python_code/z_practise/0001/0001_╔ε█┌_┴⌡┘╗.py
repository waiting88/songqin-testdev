def getName(srcStr):
    num1=srcStr.find('the name is ')
    num2=num1+len('the name is ')
    num3=srcStr.find(',',num2)
    name=srcStr[num2:num3]
    print name
getName('A gril come in,the name is Jack,level 955')





