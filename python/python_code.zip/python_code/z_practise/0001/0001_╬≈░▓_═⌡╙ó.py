def getname(srcStr):
    a=srcStr.split(',')
    return a[1][13:]
srcStr='A old lady come in, the name is Mary, level 94454'
srcStr1='A old lady come in, the name is Michael Jackson, level 94454'
print getname(srcStr)
print getname(srcStr1)
