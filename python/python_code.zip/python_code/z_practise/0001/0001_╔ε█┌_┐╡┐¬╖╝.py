def getName(srcStr):
    print srcStr.split('is')[-1].split(',')[0]
	