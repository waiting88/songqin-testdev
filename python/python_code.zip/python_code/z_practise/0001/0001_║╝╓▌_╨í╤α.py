def getName(srcStr):
    b=srcStr.find('the name is')
    c =srcStr.find(',',b)
    print srcStr[(b+11):c]

getName('A girl is come in,the name is ccccc,dddddddd')

