def getName(srcStr):
    name=srcStr.split(',')[1][12:]
    return name
