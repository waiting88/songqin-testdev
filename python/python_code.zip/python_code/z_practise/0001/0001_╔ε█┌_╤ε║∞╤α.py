def getName(srcStr):
    str1=srcStr.split(',')[-2]
    str2=str1.split('is')[-1]
    return str2



def getName1(srcStr):
    str1=srcStr.find("the name is ")+12
    #str='the name is '
    #str1=srcStr.find(str)+len(str)
    str2=srcStr.find(", level")
    str3=srcStr[str1:str2]
    return str3


testcases = [
    ('001 come in, the name is Jack, level 9;', 'Jack'),
    ('02 come in, the name is Clean, level 19;', 'Clean'),
    ('0233 come in, the name is Mike, level 330;', 'Mike'),
    ('A pretty boy come in, the name is Patrick, level 194;', 'Patrick')
]

class tester:

    @staticmethod
    def test(no, src, expectRet):
        try:
            ret = getName(src)
            print ret
            if ret == expectRet:
                print '#test {} pass'.format(no)
                return 0
            else:
                print '#test {} fail'.format(no)
                return 1
        except:
            print '#test {} fail with exception'.format(no)
            return 2


    @staticmethod
    def start():
        for idx, tc in enumerate(testcases):
            tester.test(idx + 1, tc[0], tc[1])

tester.start()