def getName(srcStr):
    a=srcStr.find('the name is ')+12
    b=srcStr.find(', level')
    i=srcStr[a:b]
    print('the name is:',i)

