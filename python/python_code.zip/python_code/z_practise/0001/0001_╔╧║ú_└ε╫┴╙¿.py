def getName(srcStr):
     return srcStr
srcStr = 'a girl come in,the name is jack,level 955'.replace(',',' ')
a = srcStr.split(' ')[-3]
print getName(a)