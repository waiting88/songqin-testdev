def getName(srcStr):
    return srcStr.split('the name is ')[1].split(',')[0]


testcases = [
    ('001 come in, the name is Jack, level 9;', 'Jack'),
    ('02 come in, the name is Clean, level 19;', 'Clean'),
    ('0233 come in, the name is Mike, level 330;', 'Mike'),
    ('A pretty boy come in, the name is Patrick, level 194;', 'Patrick')
]

class tester:

    @staticmethod
    def test(no, src, expectRet):
        try:
            ret = getName(src)
            if ret == expectRet:
                print '#test {} pass'.format(no)
                return 0
            else:
                print '#test {} fail'.format(no)
                return 1
        except:
            print '#test {} fail with exception'.format(no)
            return 2


    @staticmethod
    def start():
        for idx, tc in enumerate(testcases):
            tester.test(idx + 1, tc[0], tc[1])
