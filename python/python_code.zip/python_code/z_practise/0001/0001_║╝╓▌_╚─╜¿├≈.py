
def getName(srcStr):
    name=srcStr.split("the name is")[1].split(",")[0]
    print  name
a='A old lady come in, the name is Mary, level 94454'
getName(a)

