#encoding=utf-8
'''
设计一个函数，名为getName，如下所示，
def getName(srcStr):
    函数体
该函数分析参数字符串srcStr，将其中的人名获取出来，
参数字符串 一个例子 如下所示    
A girl  come in, the name is Jack, level 955;
其中包含的句子 the name is 后面会跟着人名，随后紧跟一个逗号， 这是固定的格式。
其它部分可能都是会变化的，比如参数可能是下面这些
A old lady come in, the name is Mary, level 94454
A pretty boy come in, the name is Patrick, level 194
'''
def getName(srcStr):
    index1 = srcStr.find('the name is')
    index2 = index1 + 11
    index3 = srcStr.find(',',(index1-1))
    name = srcStr[index2:index3]
    return name
    
list1 = 'A old lady come in, the name is Mary, level 94454'
name1 =  getName(list1)
print name1