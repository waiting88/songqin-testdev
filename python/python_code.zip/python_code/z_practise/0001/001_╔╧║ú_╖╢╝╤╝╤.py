# -*- coding: UTF-8 -*-
__author__ = 'fjj'
# example1:
def getName(strcStr):
    s = list(strcStr)
    start_index = strcStr.find('the name is') + len('the name is ')

    end_start = strcStr.find(', level')
    return ''.join(s[start_index:end_start])


str1 = 'a old lady is coming, the name is mary, level 9565'
str2 = 'a pretty boy come in,the name is Patrick, level 194'
print getName(str1)
print getName(str2)

# example2:
'''def getName(srcStr):
	index1 = srcStr.find('the name is')
	index2 = srcStr.find(',',index1)
	index1 += len('the name is ')

	return srcStr[index1:index2]
str1='a old lady is coming, the name is mary, level 9565'
str2='a pretty boy come in,the name is Patrick,level 194'
print getName(str1)
print getName(str2)'''
