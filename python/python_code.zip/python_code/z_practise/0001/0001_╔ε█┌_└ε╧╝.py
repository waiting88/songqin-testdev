def GetName(srcStr):
    FixedValue = 'the name is '
    num = len(FixedValue)

    StartIndex = srcStr.find(FixedValue)
    StartIndex1 = StartIndex + num
    EndIndex = srcStr.find('level') - 1

    Name1 = srcStr[StartIndex1:EndIndex]
    return Name1

Str1='An old lady come in,the name is Jack,level 9'
Str2='A pretty boy come in,the name is Patrick,level 39'
Str3='A gril come in,the name is Mary,level 4339'

Str=[Str1,Str2,Str3]
print 'the name you want is :' 

for str in Str:
    Name=GetName(str)
    print Name
