def getName(srcStr):

    print srcStr
    srcStr_split = srcStr.split(',')
    name_info = srcStr_split[1][12:]
    print name_info
    return name_info
    
getName('A girl come in, the name is Jack, level 955;')

getName('A old lady come in, the name is Patrick, level 194;')