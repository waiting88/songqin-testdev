def getName(srcStr):
    index1 = srcStr.find('the name is')
    index2 = srcStr.find(',',index1)
    index1 = index1+12

    print srcStr[index1:index2]