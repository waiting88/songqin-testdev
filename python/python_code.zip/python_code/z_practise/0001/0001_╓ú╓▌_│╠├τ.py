#!/usr/bin/python
# -*- coding: UTF-8 -*-
def getName(srcStr):
      a='A girl  come in, the name is Jack, level 955'
      srcStr = a.split(',')[-2][12:];
      print srcStr;
      return;
getName('A girl  come in, the name is Jack, level 955')