def getName(srcStr):
    s='A girl come in, the name is Lucy, level 955;'
    idx1=s.find('is ')
    idx2=s.find(',',idx1)
    a=s[idx1+3:idx2]
    print a
srcStr='A girl come in, the name is Lucy, level 955;'
getName(srcStr)