def getName(srcStr):
    nameImmo = 'the name is '
    start = srcStr.find(nameImmo) +len(nameImmo)
    end = srcStr.find(',',start)
    srcStr = srcStr[start:end]
    return srcStr


