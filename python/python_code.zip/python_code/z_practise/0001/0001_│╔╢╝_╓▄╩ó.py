def getName():
    srcStr='a girl come in,the name is Jack,level 955'
    a1=srcStr.find('the name is')
    a2=srcStr.find(',',a1+11)
    return srcStr[a1+11:a2]
getName() 



