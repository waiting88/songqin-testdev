def getName(srcStr):
    
    index1=srcStr.find("the name is ")
    index2=srcStr.find(", level")
    lenght=len("the name is ")
    name=srcStr[index1+12:index2]
    print name
    
getName("A girl  come in, the name is Jack, level 955;")