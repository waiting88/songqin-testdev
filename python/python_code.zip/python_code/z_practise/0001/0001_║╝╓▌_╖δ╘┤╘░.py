def getName(srcStr):
    a= srcStr.split(',')[1]
    print a.split(' ')[4]
    
getName('A girl  come in, the name is Jack, level 955')
getName('A old lady come in, the name is Mary, level 94454')
getName('A pretty boy come in, the name is Patrick, level 194')
