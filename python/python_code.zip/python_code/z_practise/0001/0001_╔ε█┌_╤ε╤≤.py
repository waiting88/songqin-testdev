def getName(srcStr):
    a=srcStr.split(',')
    b=a[1].split(' ')[-1]
    print b

getName('A old lady come in, the name is Mary, level 94454')
getName('A pretty boy come in, the name is Patrick, level 194')
