#coding = utf-8


def getName(srcStr):

    Num1 = srcStr.find('the name is')
    Num2 = srcStr.find(',',Num1)
    print srcStr[Num1+12:Num2]

getName("A girl  come in, the name is Jack, level 955")

