def getName(srcStr):
    kw = 'the name is '
    index = srcStr.find(kw)
    newStr = srcStr[index + len(kw):len(srcStr)]
    douhao = newStr.find(',')
    src = newStr[:douhao]
    return src
print getName('A little girl come in,the name is Lucy,level 9993')