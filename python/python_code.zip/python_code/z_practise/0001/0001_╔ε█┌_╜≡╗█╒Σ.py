def getName(srcStr):
	srcStr=(srcStr.split(',')[1]).split(' ')[-1]
	return srcStr