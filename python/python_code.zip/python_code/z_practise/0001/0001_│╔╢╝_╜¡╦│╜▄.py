srcStr='A old lady come in, the name is Mary, level 94454'
def getName(srcStr):
    return srcStr.find('the name is ')
x=getName(srcStr)
y=srcStr.find(',',x)
print srcStr[x+12:y] 