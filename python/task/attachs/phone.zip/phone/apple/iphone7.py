price = 6600

def askPrice():
    print('The price of iphone 7 is: %s' % price)
