price = 7800

def askPrice():
    print 'The price of galaxy s7 is: %s' % price