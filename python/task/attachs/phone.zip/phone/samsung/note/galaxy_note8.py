price = 7900

def askPrice():
    print('The price of galaxy note8 is: %s' % price)
