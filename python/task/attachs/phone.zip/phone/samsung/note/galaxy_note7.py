price = 7900

def askPrice():
    print 'The price of galaxy note7 is: %s' % price