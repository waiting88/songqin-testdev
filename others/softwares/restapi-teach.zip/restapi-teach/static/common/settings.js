
var Qiniu_BucketDomain_Video      = 'http://qa-web-video.qa.com/';
var Qiniu_BucketDomain_Picture    = 'http://323og.bkt.clouddn.com/';


//var Url_Mgr_GetUploadToken_Video      = '/api/mgr/qiniu/video/getuploadtoken';
//var Url_Mgr_GetUploadToken_Picture    = '/api/mgr/qiniu/img/getuploadtoken';

var Url_Mgr_GetUploadToken_Video      = '/api/mgr/qiniu/?action=getuploadtoken&resource_type=video';
var Url_Mgr_GetUploadToken_Picture    = '/api/mgr/qiniu/?action=getuploadtoken&resource_type=img';

var Url_Teacher_GetUploadToken_Video      = '/api/teacher/qiniu/?action=getuploadtoken&resource_type=video';
var Url_Teacher_GetUploadToken_Picture    = '/api/teacher/qiniu/?action=getuploadtoken&resource_type=img';


var Url_DataInputer_GetUploadToken_Video      = '/api/operator/qiniu/?action=getuploadtoken&resource_type=video';
var Url_DataInputer_GetUploadToken_Picture    = '/api/operator/qiniu/?action=getuploadtoken&resource_type=img';


