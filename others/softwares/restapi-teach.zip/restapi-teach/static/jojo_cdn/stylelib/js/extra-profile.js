$(function() {
    //BEGIN PLUGINS DATE PICKER
    $('.datepicker-normal').datepicker();
    //END PLUGINS DATE PICKER
});
		