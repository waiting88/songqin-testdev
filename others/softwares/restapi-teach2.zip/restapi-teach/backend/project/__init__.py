import os
# from celery import Celery

# set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'project.settings')


# app = Celery('django')
#
# app.config_from_object('project.celerytasks.celery_worker_cfg')

