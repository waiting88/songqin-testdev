cd backend
python project/cherrypy_startup.py &> /dev/null &