
MgrLoginUrl=        'http://localhost/mgr/login/login.html'
adminuser=          {'name':'auto',    'pw':'sdfsdfsdf'}