import sys

sys.path.append(r"D:\gsync\workspace\sq\python\samples\z_practise\0006\practise\phone\apple")

from  iphone6 import askPrice


askPrice()


