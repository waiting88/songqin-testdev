price = 5600

def askPrice():
    print('The price of iphone 6 is: %s' % price)
