# coding=utf8

welcome = " 你好，欢迎到松勤学习。 我们将为您提供良好的学习环境，多对一的贴心服务。下面是我们的服务细节..."

print "小王"  + welcome
print "小张"  + welcome
print "小李"  + welcome
print "小刘"  + welcome

