score = 40
if score >= 90:
    print('your score is', score)
    print('excellent')
elif score >= 60:  # (score < 90)
    print('your score is', score)
    print('ok')
elif score >= 40:  # (score < 90)
    print('your score is', score)
    print('补考')
else:   # (score < 40)
    print('your score is', score)
    print('you have trouble')

