score = 50
if score >= 90:
    print('your score is', score)
    print('excellent')
elif score >= 60:  # (score < 90)
    print('your score is', score)
    print('ok')
else:   # (score < 60)
    print('your score is', score)
    print('you have trouble')

