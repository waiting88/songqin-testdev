def sayHello():
    print("hello")


def sayGoodbye():
    print ("goodbye")

# testing code
print ('exec testing')
sayHello()
sayGoodbye()