def sayHello():
    print ("hello")

def sayGoodbye():
    print ("goodbye")

print(__name__)

if __name__ == "__main__":
    print ('exec testing')
    sayHello()
    sayGoodbye()
