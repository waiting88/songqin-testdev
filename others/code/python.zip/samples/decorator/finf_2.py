def foo():
    class My():
        pass

    print('in foo()')
    My()

foo()
