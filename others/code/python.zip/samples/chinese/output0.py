
print('中文')
