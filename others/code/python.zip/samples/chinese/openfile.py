with open('中文.txt',encoding='utf8') as f:
    print(f.read())
