a = input('请输入:')
import sys

print(sys.stdin.encoding)
print(a)