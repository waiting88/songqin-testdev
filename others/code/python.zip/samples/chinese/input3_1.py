fh = open('file3.txt','r',encoding='utf8')
bcStr = fh.read() # 这里返回的是bytes类型
fh.close()



print(bcStr)
print(len(bcStr))
print(bcStr[2])

