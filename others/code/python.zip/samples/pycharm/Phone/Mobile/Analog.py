from pycharm.common_util import HOST_NAME

print(HOST_NAME)


def dial():
    print('Mobile-Analog dial')
