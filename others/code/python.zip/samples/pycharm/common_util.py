HOST_NAME = 'newyork'

# import thirdparty.lib99