def func1():
    print('hello 1')

def func2():
    print('hello 2')

def func3():
    print('hello 3')

import time

func1()
time.sleep(10)
func2()
time.sleep(10)
func3()
