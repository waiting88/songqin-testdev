import os
ret = os.system('dir sdfsdfsdfsdf')
print(ret)
