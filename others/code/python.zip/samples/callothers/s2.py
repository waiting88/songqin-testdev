from subprocess import  Popen
popen = Popen(
        args='mspaint',
        shell=True
    )
print('done')

