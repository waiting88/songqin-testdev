import os
os.system('mspaint')
print('after call')
