try:
    4/0
    ohmy
except Exception as e:
    print('handle unkown exception:', e)

print('结尾')