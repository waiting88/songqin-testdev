def  inputname():
    name = input('请输入姓名:')
    if len(name)>10:
        return 1,None
    if len(name)<6:
        return 2,None
    return 0,name

retcode, name = inputname()
if retcode == 0:
    print(name)
else:
    print('输入错误')
