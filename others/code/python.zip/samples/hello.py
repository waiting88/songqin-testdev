inList = [1,0,5,0,34,23,55,56,2,3,4]

def sort(inList):
    newList = []

    while inList !=[]:
        theMin = inList[0]
        minIdx = 0

        idx = 0
        for one in inList:
            if theMin > one:
                theMin = one
                minIdx = idx


            idx += 1
        inList.pop(minIdx)
        newList.append(theMin)

    return newList

print(sort(inList))