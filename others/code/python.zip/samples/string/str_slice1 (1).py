str1 = '11:12:11> 001 enter chatroom, level 2'
print str1 [10:10+3]

str2 = '11:12:11> level 2, 007 enter chatroom'
print str2 [-18:-18+3]