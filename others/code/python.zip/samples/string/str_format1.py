name = 'jcy'
height = 170

print('my name is ' + name + ', and I am ' + str(height) + 'cm tall.')


