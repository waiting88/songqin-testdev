name = 'jcy'
height = 170
print ('我叫%s, 身高%scm' % (name,height))


print ('我叫{}, 身高{}cm'.format(name,height))


print (f'我叫{name}, 身高{height}cm')



# data = {'name': "jcy", "height": 170}
# print ('我叫%(name)s, 身高%(height)scm' % data)
