boys  = ['Mike','Jack','Tom']
girls = ['Lisa','Linda','Mary']
for boy in boys:
    for girl in girls:
        print('%s shakes %s' % (boy, girl))
