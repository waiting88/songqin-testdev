cur = 1
while cur <= 100:
    print(cur)
    cur += 1

