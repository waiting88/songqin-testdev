def func1():
    print('now we are in func1')


print('before func1')
func1()
print("after  func1")


