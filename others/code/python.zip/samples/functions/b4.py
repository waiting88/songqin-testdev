def func1():
    print(1)
    return
    print(2)
    print(3)


print(func1())
print(4)
