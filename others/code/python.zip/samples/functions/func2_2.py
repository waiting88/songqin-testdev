x = 2

def func():
    print("this x is in the func:-->", x)


func()
print("--------------------------")
print("this x is out of func:-->", x)

