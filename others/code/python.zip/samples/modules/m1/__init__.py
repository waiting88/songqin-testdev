print('m1 init')

def m1_f():
    print('m1_f')