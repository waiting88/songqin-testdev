from calc import calc_s_c,var1

calc_s_c(20)

print(var1)

