def dial():
    print('Mobile-Analog dial')
