import calc

calc.calc_s_c(20)

    
print calc.var1

calc.var1 = 500


