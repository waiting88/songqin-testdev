import Phone.Mobile.Analog
Phone.Mobile.Analog.dial()

# import Phone
# Phone.abc
# print(type(Phone))
# print(Phone.abc)

