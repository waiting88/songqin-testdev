from Phone import Mobile

Mobile.Analog.dial()

