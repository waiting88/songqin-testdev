
print __name__

import os
print os.__file__