from Phone.Mobile import Analog
Analog.dial()