a1 = 3

print a1