from Phone.Mobile.Analog import dial
dial()

print type(dial)