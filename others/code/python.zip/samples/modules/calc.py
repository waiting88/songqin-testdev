print('*** in calc  begin *** ')
var1 = 20

def calc_s(num):
    print('square of num is %s' % num ** 2)


def calc_c(num):
    print('cube   of num is %s' % num ** 3)


def calc_s_c(num):
    print('square of num is %s' % num ** 2)
    print('cube   of num is %s' % num ** 3)

print('*** in calc  end *** ')