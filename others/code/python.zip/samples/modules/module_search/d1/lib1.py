def fun1():
    print('in lib1.func1')


CONF_ITEM = 'LIB1_CONFIGURE'