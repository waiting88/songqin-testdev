from appium import webdriver
import time,traceback
desired_caps = {}
desired_caps['platformName'] = 'Android'
desired_caps['platformVersion'] = '6'
desired_caps['deviceName'] = 'test'
desired_caps['appPackage'] ='com.rss100.rssjh_design'
desired_caps['appActivity'] ='com.rss100.rssjh_design.ui.WelcomeActivity'
desired_caps['unicodeKeyboard']  = True
desired_caps['resetKeyboard']  = True
desired_caps['noReset'] = True
desired_caps['newCommandTimeout'] = 6000
#启动Remote RPC
driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)

try:
    driver.implicitly_wait(10)

    # 根据id找到元素，并点击，id和 html 元素的id不同
    driver.find_element_by_id("android:id/button2").click()
    time.sleep(1)
    driver.find_element_by_id('com.rss100.rssjh_design:id/main_mine_img').click()
    time.sleep(2)
    # xpath = "//*[@resourse-id='com.rss100.rssjh_design:id/main_mine_lyt']//android.widget.ImageButton"
    # driver.find_element_by_xpath(xpath).click()
    time.sleep(2)
    driver.find_element_by_id("com.rss100.rssjh_design:id/mine_avatar_image").click()
    time.sleep(2)


    # 输入用户名、密码

    ele = driver.find_element_by_id("com.rss100.rssjh_design:id/registe_edit_upper")
    ele.send_keys('13168080549')
    ele = driver.find_element_by_id("com.rss100.rssjh_design:id/registe_edit_down")
    ele.send_keys('qq123123')

    time.sleep(2)
    # 点击登录
    driver.find_element_by_id('com.rss100.rssjh_design:id/login_sure').click()
    pass

except:
    print (traceback.format_exc())


input('**** Press to quit..')
driver.quit()